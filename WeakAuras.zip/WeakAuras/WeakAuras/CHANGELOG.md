# [2.14.6](https://github.com/WeakAuras/WeakAuras2/tree/2.14.6) (2019-08-30)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/2.14.5...2.14.6)

## Highlights

 - Bug fixes! Bug fixes! Get your bug fixes! 

## Commits

InfusOnWoW (1):

- Fix regression Talent Selected Trigger

LAMBOLEY Lucas (1):

- Update .luacheckrc

Stanzilla (2):

- add back the missing true(th)
- remove last remnants of sticky duration, see our [wiki](https://github.com/WeakAuras/WeakAuras2/wiki/Deprecations) on what to use instead

Vardex (1):

- Fix wrong duration for oh enchantment

mrbuds (5):

- fix nil error in stance trigger
- fix WeakAuras.GetProperties with unknown region type fixes #1643
- classic: WA_GetUnitAura return duration & expirationTime from LibClassicDurations
- fix a bug with combat log trigger arguments fix #1638
- classic: fix register unknown event in bufftrigger1

