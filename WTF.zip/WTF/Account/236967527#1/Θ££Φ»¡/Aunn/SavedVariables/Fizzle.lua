
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Aunn - 霜语"] = "Aunn - 霜语",
	},
	["profiles"] = {
		["Aunn - 霜语"] = {
		},
	},
}
