
NeatPlatesOptions = {
	["WelcomeShown"] = true,
	["HealthFrequent"] = true,
	["SecondSpecProfile"] = "默认",
	["FriendlyAutomation"] = "不使用自动化",
	["EnemyAutomation"] = "不使用自动化",
	["NameplateClickableWidth"] = 1,
	["FourthSpecProfile"] = "默认",
	["ThirdSpecProfile"] = "默认",
	["ForceBlizzardFont"] = false,
	["DisableCastBars"] = false,
	["EnforceRequiredCVars"] = true,
	["BlizzardScaling"] = false,
	["ActiveTheme"] = "Neon",
	["NameplateClickableHeight"] = 1,
	["OverrideOutline"] = 1,
	["FirstSpecProfile"] = "默认",
}
