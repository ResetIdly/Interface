
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["小雨阿 - 霜语"] = "小雨阿 - 霜语",
	},
	["profiles"] = {
		["小雨阿 - 霜语"] = {
		},
	},
}
