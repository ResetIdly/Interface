
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["小德阿 - 霜语"] = "小德阿 - 霜语",
	},
	["profiles"] = {
		["小德阿 - 霜语"] = {
		},
	},
}
