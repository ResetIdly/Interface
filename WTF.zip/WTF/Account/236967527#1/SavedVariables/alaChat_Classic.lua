
alaBaseData = {
	["xBtn"] = {
		["posEx"] = "BELOW_EDITBOX",
		["scale"] = 0.8,
		["alpha"] = 1,
		["_version"] = 1.05,
		["pos"] = {
			"TOPLEFT", -- [1]
			"ChatFrame1EditBox", -- [2]
			"BOTTOMLEFT", -- [3]
			0, -- [4]
			-1.00000011920929, -- [5]
		},
	},
}
alaChatConfig = {
	["scale"] = 0.8,
	["ReadyCheck"] = true,
	["shortChannelName"] = true,
	["bfWorld_Ignore_BtnSize"] = 28,
	["channelBarChannel"] = {
		true, -- [1]
		true, -- [2]
		true, -- [3]
		true, -- [4]
		true, -- [5]
		true, -- [6]
		true, -- [7]
		false, -- [8]
		false, -- [9]
		true, -- [10]
		false, -- [11]
		false, -- [12]
		false, -- [13]
		true, -- [14]
	},
	["filterQuestAnn"] = false,
	["bfWorld_Ignore_Switch"] = false,
	["level"] = false,
	["ColorNameByClass"] = true,
	["copy"] = false,
	["welcomeToGuild"] = false,
	["_version"] = 190831,
	["chatEmote"] = true,
	["alpha"] = 1,
	["shamanColor"] = false,
	["roll"] = true,
	["position"] = "BELOW_EDITBOX",
	["editBoxTab"] = false,
	["itemLinkEnhanced"] = true,
	["DBMCountDown"] = true,
	["channelBarStyle"] = "CHAR",
	["broadCastNewMember"] = false,
	["bfWorld_Ignore"] = false,
}
