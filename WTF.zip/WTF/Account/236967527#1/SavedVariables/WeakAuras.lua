
WeakAurasSaved = {
	["dynamicIconCache"] = {
	},
	["displays"] = {
		["暗影伤害"] = {
			["outline"] = "THICKOUTLINE",
			["color"] = {
				0.431372549019608, -- [1]
				0.368627450980392, -- [2]
				0.63921568627451, -- [3]
				1, -- [4]
			},
			["displayText"] = "暗影伤害: +%c",
			["customText"] = "-- Change out the number in the first line to track your desired spell type.\n--\n-- example: GetSpellBonusDamage(6) to track Shadow damage.\n--\n-- 1 for Physical\n-- 2 for Holy\n-- 3 for Fire\n-- 4 for Nature\n-- 5 for Frost  (default)\n-- 6 for Shadow\n-- 7 for Arcane\n--\n-----------------------------------------------------------------\n\nfunction ()\n    local spellDmg = GetSpellBonusDamage(6)\n    return (\"%.f\"):format(spellDmg)\n    \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_strength"] = true,
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["use_unit"] = true,
						["unit"] = "player",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["selfPoint"] = "BOTTOM",
			["desc"] = "Current Bonus Spell Damage",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["WARLOCK"] = true,
						["PRIEST"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["justify"] = "LEFT",
			["xOffset"] = 0,
			["parent"] = "角色属性",
			["semver"] = "1.0.3",
			["tocversion"] = 11302,
			["id"] = "暗影伤害",
			["fixedWidth"] = 200,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["authorOptions"] = {
			},
			["config"] = {
			},
			["wordWrap"] = "WordWrap",
			["uid"] = "WV4XBOmVLxN",
			["conditions"] = {
				{
					["check"] = {
					},
					["changes"] = {
						{
						}, -- [1]
					},
				}, -- [1]
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
			},
			["automaticWidth"] = "Auto",
		},
		["Agility"] = {
			["outline"] = "THICKOUTLINE",
			["authorOptions"] = {
			},
			["displayText"] = "敏捷:%c",
			["customText"] = "function(unit, cache, textframe)\n    local agility = UnitStat(\"player\", 2)\n    \n    return (\" %.f\"):format(agility)\nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Conditions",
						["subeventPrefix"] = "SPELL",
						["use_strength"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["ownOnly"] = true,
						["unit"] = "player",
						["use_unit"] = true,
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_form"] = false,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Stance/Form/Aura",
						["subeventPrefix"] = "SPELL",
						["unevent"] = "auto",
						["type"] = "status",
						["form"] = {
							["multi"] = {
								[4] = true,
							},
						},
						["unit"] = "player",
						["use_unit"] = true,
						["use_inverse"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
			["desc"] = "Current Agility",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["HUNTER"] = true,
						["WARRIOR"] = true,
						["ROGUE"] = true,
						["DRUID"] = true,
						["SHAMAN"] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "Agility",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["config"] = {
			},
			["uid"] = "AIsE037Xq8q",
			["xOffset"] = 0,
			["color"] = {
				0.96470588235294, -- [1]
				1, -- [2]
				0.54117647058824, -- [3]
				1, -- [4]
			},
			["fixedWidth"] = 200,
			["selfPoint"] = "BOTTOM",
			["wordWrap"] = "WordWrap",
		},
		["Intellect"] = {
			["outline"] = "THICKOUTLINE",
			["authorOptions"] = {
			},
			["displayText"] = "智力:%c",
			["customText"] = "function(unit, cache, textframe)\n    local intellect = UnitStat(\"player\", 4)\n    \n    return (\" %.f\"):format(intellect)\nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Conditions",
						["names"] = {
						},
						["use_strength"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["ownOnly"] = true,
						["unit"] = "player",
						["use_unit"] = true,
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_form"] = false,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Stance/Form/Aura",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["type"] = "status",
						["form"] = {
							["multi"] = {
								true, -- [1]
								true, -- [2]
								true, -- [3]
								true, -- [4]
							},
						},
						["use_unit"] = true,
						["unit"] = "player",
						["use_inverse"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["selfPoint"] = "BOTTOM",
			["desc"] = "Current Intellect",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["WARLOCK"] = true,
						["SHAMAN"] = true,
						["MAGE"] = true,
						["DRUID"] = true,
						["PALADIN"] = true,
						["PRIEST"] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["justify"] = "LEFT",
			["color"] = {
				0.37254901960784, -- [1]
				1, -- [2]
				0.96470588235294, -- [3]
				1, -- [4]
			},
			["parent"] = "角色属性",
			["semver"] = "1.0.3",
			["tocversion"] = 11302,
			["id"] = "Intellect",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 0,
			["uid"] = "bcVFqRXLiAR",
			["wordWrap"] = "WordWrap",
			["config"] = {
			},
			["fixedWidth"] = 200,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
			["automaticWidth"] = "Auto",
		},
		["角色属性"] = {
			["grow"] = "UP",
			["controlledChildren"] = {
				"宠物状态", -- [1]
				"物理命中", -- [2]
				"Melee Crit ", -- [3]
				"法术命中", -- [4]
				"Spell Crit", -- [5]
				"远程暴击", -- [6]
				"Armor Reduction % (DR)", -- [7]
				"Total Armor", -- [8]
				"攻强", -- [9]
				"远程攻强", -- [10]
				"+ Healing ", -- [11]
				"Mp5", -- [12]
				"Dodge Chance", -- [13]
				"Parry Chance", -- [14]
				"Block Chance", -- [15]
				"冰霜伤害", -- [16]
				"火焰伤害", -- [17]
				"暗影伤害", -- [18]
				"Agility", -- [19]
				"Stamina", -- [20]
				"Strength", -- [21]
				"Intellect", -- [22]
				"Spirit", -- [23]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["xOffset"] = 764.978597005208,
			["yOffset"] = -602.230244954427,
			["gridType"] = "RD",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["rowSpace"] = 1,
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["event"] = "Health",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["useLimit"] = false,
			["align"] = "LEFT",
			["desc"] = "Character Stat Display",
			["rotation"] = 0,
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["anchorPoint"] = "CENTER",
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["arcLength"] = 360,
			["animate"] = true,
			["space"] = 3,
			["scale"] = 0.75,
			["useAnchorPerUnit"] = false,
			["border"] = false,
			["borderEdge"] = "1 Pixel",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 6,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["sort"] = "descending",
			["constantFactor"] = "RADIUS",
			["config"] = {
			},
			["borderOffset"] = 4,
			["semver"] = "1.0.3",
			["tocversion"] = 11302,
			["id"] = "角色属性",
			["internalVersion"] = 24,
			["gridWidth"] = 5,
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 1,
			["borderInset"] = 1,
			["uid"] = "UR)w6Pb4UKM",
			["stagger"] = 0,
			["conditions"] = {
			},
			["selfPoint"] = "BOTTOMLEFT",
			["authorOptions"] = {
			},
		},
		["Mp5"] = {
			["outline"] = "THICKOUTLINE",
			["xOffset"] = 0,
			["displayText"] = "Mp5: %c",
			["customText"] = "function()\n    local base, casting = GetManaRegen('player') * 4.99\n    return (\"%.f\"):format(base, casting) \n    \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_strength"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_form"] = false,
						["unevent"] = "auto",
						["form"] = {
							["multi"] = {
								true, -- [1]
								true, -- [2]
								true, -- [3]
								true, -- [4]
							},
						},
						["event"] = "Stance/Form/Aura",
						["unit"] = "player",
						["type"] = "status",
						["use_resting"] = false,
						["use_unit"] = true,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["subeventPrefix"] = "SPELL",
						["use_inverse"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
			},
			["desc"] = "Current Mana Per 5 Seconds",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["SHAMAN"] = true,
						["DRUID"] = true,
						["PALADIN"] = true,
						["PRIEST"] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["authorOptions"] = {
			},
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "Mp5",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["color"] = {
				0.74117647058823, -- [1]
				0.74117647058823, -- [2]
				0.67843137254902, -- [3]
				1, -- [4]
			},
			["config"] = {
			},
			["wordWrap"] = "WordWrap",
			["uid"] = "NEksuYBgIV1",
			["fixedWidth"] = 200,
			["selfPoint"] = "BOTTOM",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
		},
		["Spell Crit"] = {
			["outline"] = "THICKOUTLINE",
			["xOffset"] = 0,
			["displayText"] = "法术暴击: %c%",
			["customText"] = "function()\n    local crit = GetSpellCritChance()\n    return (\"%.1f\"):format(crit)\n    \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_strength"] = true,
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["unit"] = "player",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["wordWrap"] = "WordWrap",
			["desc"] = "Current Spell Crit Rating",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["WARLOCK"] = true,
						["SHAMAN"] = true,
						["MAGE"] = true,
						["DRUID"] = true,
						["PRIEST"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["authorOptions"] = {
			},
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "Spell Crit",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["selfPoint"] = "BOTTOM",
			["uid"] = "VDDHrvlJqXk",
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
			["config"] = {
			},
			["fixedWidth"] = 200,
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["color"] = {
				0.37254901960784, -- [1]
				1, -- [2]
				0.96470588235294, -- [3]
				1, -- [4]
			},
		},
		["Spirit"] = {
			["outline"] = "THICKOUTLINE",
			["xOffset"] = 0,
			["displayText"] = "精神:%c",
			["customText"] = "function(unit, cache, textframe)\n    local spirit = UnitStat(\"player\", 5)\n    \n    return (\" %.f\"):format(spirit)\nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Conditions",
						["subeventPrefix"] = "SPELL",
						["use_strength"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["ownOnly"] = true,
						["unit"] = "player",
						["use_unit"] = true,
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_form"] = false,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Stance/Form/Aura",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["type"] = "status",
						["form"] = {
							["multi"] = {
								true, -- [1]
								true, -- [2]
								true, -- [3]
								true, -- [4]
							},
						},
						["use_unit"] = true,
						["unit"] = "player",
						["use_inverse"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["wordWrap"] = "WordWrap",
			["desc"] = "Current Spirit",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["talent"] = {
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["WARLOCK"] = true,
						["PALADIN"] = true,
						["MAGE"] = true,
						["DRUID"] = true,
						["SHAMAN"] = true,
						["PRIEST"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "Spirit",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "KLvuhGf3x1K",
			["config"] = {
			},
			["color"] = {
				0.650980392156863, -- [1]
				0.705882352941177, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["fixedWidth"] = 200,
			["selfPoint"] = "BOTTOM",
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
		},
		["火焰伤害"] = {
			["outline"] = "THICKOUTLINE",
			["color"] = {
				0.937254901960784, -- [1]
				0.290196078431373, -- [2]
				0.0627450980392157, -- [3]
				1, -- [4]
			},
			["displayText"] = "火焰伤害: +%c",
			["customText"] = "-- Change out the number in the first line to track your desired spell type.\n--\n-- example: GetSpellBonusDamage(6) to track Shadow damage.\n--\n-- 1 for Physical\n-- 2 for Holy\n-- 3 for Fire\n-- 4 for Nature\n-- 5 for Frost  (default)\n-- 6 for Shadow\n-- 7 for Arcane\n--\n-----------------------------------------------------------------\n\nfunction ()\n    local spellDmg = GetSpellBonusDamage(3)\n    return (\"%.f\"):format(spellDmg)\n    \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_strength"] = true,
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["use_unit"] = true,
						["unit"] = "player",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["selfPoint"] = "BOTTOM",
			["desc"] = "Current Bonus Spell Damage",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["MAGE"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["justify"] = "LEFT",
			["xOffset"] = 0,
			["parent"] = "角色属性",
			["semver"] = "1.0.3",
			["tocversion"] = 11302,
			["id"] = "火焰伤害",
			["fixedWidth"] = 200,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["authorOptions"] = {
			},
			["config"] = {
			},
			["wordWrap"] = "WordWrap",
			["uid"] = "VTVgLILakZ)",
			["conditions"] = {
				{
					["check"] = {
					},
					["changes"] = {
						{
						}, -- [1]
					},
				}, -- [1]
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
			},
			["automaticWidth"] = "Auto",
		},
		["宠物状态"] = {
			["outline"] = "THICKOUTLINE",
			["xOffset"] = 0,
			["displayText"] = "============\n宠物信息：\n%c\n============",
			["customText"] = "function()\n    \n    function round(number, decimals)\n        return ((\"%%.%df\"):format(decimals)):format(number)\n    end\n    \n    happiness, damagePercentage, loyaltyRate = GetPetHappiness()\n    if happiness then\n        if happiness == 3 then\n            level = \"|CFF20C000开心\"\n            damage = \"|CFF20C000\"..damagePercentage..\"%\"\n            rate = \"|CFF20C000\"..loyaltyRate\n        elseif happiness == 2 then\n            level = \"|CFFFE8A0E满足\"\n            damage = \"|CFFFE8A0E\"..damagePercentage..\"%\"\n            rate = \"|CFFFE8A0E\"..loyaltyRate\n        else\n            level = \"|CFFFF0303不满\"\n            damage = \"|CFFFF0303\"..damagePercentage..\"%\"\n            rate = \"|CFFFF0303\"..loyaltyRate\n        end\n        \n        currXP, nextXP = GetPetExperience()\n        local percent = round((currXP/nextXP)*100,0)\n        petLevel = UnitLevel(\"pet\")\n        \n        return \"状态: \"..level..\"|CFFFFFFFF\\n忠诚度: \"..rate..\"|CFFFFFFFF\\n伤害: \"..damage..\"|CFFFFFFFF\\n等级: \"..petLevel..\"\\n|CFFFFFFFF经验: |CFFFF0303\"..currXP..\"|CFFFFFFFF\\\\\"..nextXP..\" \"..percent..\"%\"\n    end        \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Fixed",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["use_strength"] = true,
						["ownOnly"] = true,
						["event"] = "Conditions",
						["names"] = {
						},
						["duration"] = "1",
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["use_unit"] = true,
						["unit"] = "player",
						["use_HasPet"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_form"] = false,
						["subeventSuffix"] = "_CAST_START",
						["form"] = {
							["multi"] = {
								nil, -- [1]
								true, -- [2]
								true, -- [3]
								true, -- [4]
							},
						},
						["event"] = "Stance/Form/Aura",
						["unit"] = "player",
						["unevent"] = "auto",
						["type"] = "status",
						["duration"] = "1",
						["subeventPrefix"] = "SPELL",
						["use_inverse"] = true,
						["use_unit"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["selfPoint"] = "BOTTOM",
			["desc"] = "Total Armor",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["use_itemequiped"] = false,
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
						["HUNTER"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["wordWrap"] = "WordWrap",
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "宠物状态",
			["conditions"] = {
			},
			["frameStrata"] = 4,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "VsZ9OrDHT)B",
			["config"] = {
			},
			["color"] = {
				1, -- [1]
				0.992156862745098, -- [2]
				0.976470588235294, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["fixedWidth"] = 200,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
			["url"] = "https://wago.io/Bu9rVLe2l/4",
		},
		["Stamina"] = {
			["outline"] = "THICKOUTLINE",
			["xOffset"] = 0,
			["displayText"] = "耐力:%c",
			["customText"] = "function(unit, cache, textframe)\n    local stamina = UnitStat(\"player\", 3)\n    \n    return (\" %.f\"):format(stamina)\nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Conditions",
						["names"] = {
						},
						["use_strength"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["ownOnly"] = true,
						["unit"] = "player",
						["use_unit"] = true,
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_form"] = false,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Stance/Form/Aura",
						["subeventPrefix"] = "SPELL",
						["unevent"] = "auto",
						["type"] = "status",
						["form"] = {
							["multi"] = {
								true, -- [1]
								true, -- [2]
								true, -- [3]
								true, -- [4]
							},
						},
						["unit"] = "player",
						["use_unit"] = true,
						["use_inverse"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["wordWrap"] = "WordWrap",
			["desc"] = "Current Stamina",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["MAGE"] = true,
						["DRUID"] = true,
						["ROGUE"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "Stamina",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "NNvCHW7F3xu",
			["config"] = {
			},
			["authorOptions"] = {
			},
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.85098039215686, -- [3]
				1, -- [4]
			},
			["fixedWidth"] = 200,
			["selfPoint"] = "BOTTOM",
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
		},
		["冰霜伤害"] = {
			["outline"] = "THICKOUTLINE",
			["color"] = {
				0, -- [1]
				0.835294117647059, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText"] = "冰霜伤害: +%c",
			["customText"] = "-- Change out the number in the first line to track your desired spell type.\n--\n-- example: GetSpellBonusDamage(6) to track Shadow damage.\n--\n-- 1 for Physical\n-- 2 for Holy\n-- 3 for Fire\n-- 4 for Nature\n-- 5 for Frost  (default)\n-- 6 for Shadow\n-- 7 for Arcane\n--\n-----------------------------------------------------------------\n\nfunction ()\n    local spellDmg = GetSpellBonusDamage(5)\n    return (\"%.f\"):format(spellDmg)\n    \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_strength"] = true,
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["unit"] = "player",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
			["desc"] = "Current Bonus Spell Damage",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["MAGE"] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["authorOptions"] = {
			},
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "冰霜伤害",
			["conditions"] = {
				{
					["check"] = {
					},
					["changes"] = {
						{
						}, -- [1]
					},
				}, -- [1]
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 0,
			["config"] = {
			},
			["wordWrap"] = "WordWrap",
			["uid"] = "KrsFyQA04Nx",
			["fixedWidth"] = 200,
			["selfPoint"] = "BOTTOM",
			["automaticWidth"] = "Auto",
		},
		["Dodge Chance"] = {
			["outline"] = "THICKOUTLINE",
			["authorOptions"] = {
			},
			["displayText"] = "闪避:%c%",
			["customText"] = "function()\n    local dodge = GetDodgeChance()\n    return (\" %.1f\"):format(dodge)\n    \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_strength"] = true,
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["unit"] = "player",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["dodgepercent"] = "0",
						["duration"] = "1",
						["event"] = "Character Stats",
						["subeventPrefix"] = "SPELL",
						["use_dodgepercent"] = true,
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["use_unit"] = true,
						["dodgepercent_operator"] = ">",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["form"] = {
							["multi"] = {
							},
						},
						["event"] = "Stance/Form/Aura",
						["subeventPrefix"] = "SPELL",
						["unevent"] = "auto",
						["use_form"] = false,
						["use_inverse"] = false,
						["unit"] = "player",
						["use_unit"] = true,
						["duration"] = "1",
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
			["desc"] = "Current Dodge Chance",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_spellknown"] = false,
				["use_never"] = false,
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["PALADIN"] = true,
						["WARRIOR"] = true,
						["DRUID"] = true,
						["ROGUE"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["spellknown"] = 5487,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["justify"] = "LEFT",
			["parent"] = "角色属性",
			["xOffset"] = 0,
			["semver"] = "1.0.3",
			["tocversion"] = 11302,
			["id"] = "Dodge Chance",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "lPpHhJru4cu",
			["config"] = {
			},
			["selfPoint"] = "BOTTOM",
			["color"] = {
				0.729411764705882, -- [1]
				0.764705882352941, -- [2]
				0.698039215686275, -- [3]
				1, -- [4]
			},
			["fixedWidth"] = 200,
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["wordWrap"] = "WordWrap",
		},
		["Melee Crit "] = {
			["outline"] = "THICKOUTLINE",
			["authorOptions"] = {
			},
			["displayText"] = "近战暴击: %c%",
			["customText"] = "function()\n    local crit = GetCritChance()\n    return (\"%.1f\"):format(crit)\n    \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_strength"] = true,
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["unit"] = "player",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["dodgepercent"] = "0",
						["duration"] = "1",
						["event"] = "Character Stats",
						["subeventPrefix"] = "SPELL",
						["use_dodgepercent"] = false,
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["use_unit"] = true,
						["dodgepercent_operator"] = ">",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Stance/Form/Aura",
						["use_unit"] = true,
						["use_spellName"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_form"] = false,
						["form"] = {
							["single"] = 3,
							["multi"] = {
								[3] = true,
							},
						},
						["subeventPrefix"] = "SPELL",
						["use_inverse"] = false,
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["wordWrap"] = "WordWrap",
			["desc"] = "Current Melee Crit Rating",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["HUNTER"] = true,
						["WARRIOR"] = true,
						["ROGUE"] = true,
						["DRUID"] = true,
						["PALADIN"] = true,
						["SHAMAN"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "Melee Crit ",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "v4G5GkemoL)",
			["config"] = {
			},
			["color"] = {
				1, -- [1]
				0.74117647058823, -- [2]
				0.5921568627451, -- [3]
				1, -- [4]
			},
			["xOffset"] = 0,
			["fixedWidth"] = 200,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
			["selfPoint"] = "BOTTOM",
		},
		["Strength"] = {
			["outline"] = "THICKOUTLINE",
			["authorOptions"] = {
			},
			["displayText"] = "力量:%c",
			["customText"] = "function(unit, cache, textframe)\n    local strength = UnitStat(\"player\", 1)\n    \n    return (\" %.f\"):format(strength)\nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Conditions",
						["names"] = {
						},
						["use_strength"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["ownOnly"] = true,
						["unit"] = "player",
						["use_unit"] = true,
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_form"] = false,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Stance/Form/Aura",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["type"] = "status",
						["form"] = {
							["multi"] = {
								[4] = true,
							},
						},
						["use_unit"] = true,
						["unit"] = "player",
						["use_inverse"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
			["desc"] = "Current Strength",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["WARRIOR"] = true,
						["ROGUE"] = true,
						["PALADIN"] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["justify"] = "LEFT",
			["xOffset"] = 0,
			["parent"] = "角色属性",
			["semver"] = "1.0.3",
			["tocversion"] = 11302,
			["id"] = "Strength",
			["fixedWidth"] = 200,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["color"] = {
				1, -- [1]
				0.6156862745098, -- [2]
				0.50588235294118, -- [3]
				1, -- [4]
			},
			["config"] = {
			},
			["wordWrap"] = "WordWrap",
			["uid"] = "COCSxmbhdg8",
			["conditions"] = {
			},
			["selfPoint"] = "BOTTOM",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
		},
		["法术命中"] = {
			["outline"] = "THICKOUTLINE",
			["xOffset"] = 0,
			["displayText"] = "法术命中: %c%",
			["customText"] = "function()\n    local crit = GetSpellHitModifier()\n    return (\"%.1f\"):format(crit)\n    \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_strength"] = true,
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["unit"] = "player",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["dodgepercent"] = "0",
						["duration"] = "1",
						["event"] = "Character Stats",
						["subeventPrefix"] = "SPELL",
						["use_dodgepercent"] = false,
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["use_unit"] = true,
						["dodgepercent_operator"] = ">",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Stance/Form/Aura",
						["use_unit"] = true,
						["use_spellName"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_form"] = false,
						["form"] = {
							["single"] = 3,
							["multi"] = {
								[3] = true,
							},
						},
						["subeventPrefix"] = "SPELL",
						["use_inverse"] = false,
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["selfPoint"] = "BOTTOM",
			["desc"] = "Current Melee Crit Rating",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["WARLOCK"] = true,
						["SHAMAN"] = true,
						["MAGE"] = true,
						["DRUID"] = true,
						["PRIEST"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["color"] = {
				1, -- [1]
				0.996078431372549, -- [2]
				0.992156862745098, -- [3]
				1, -- [4]
			},
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "法术命中",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["authorOptions"] = {
			},
			["config"] = {
			},
			["wordWrap"] = "WordWrap",
			["uid"] = "agj5G(lnN1f",
			["fixedWidth"] = 200,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
			["automaticWidth"] = "Auto",
		},
		["远程攻强"] = {
			["outline"] = "THICKOUTLINE",
			["authorOptions"] = {
			},
			["displayText"] = "远程攻强:%c",
			["customText"] = "function()\n    local base,posBuff,negBuff = UnitRangedAttackPower(\"player\")\n    local effectiveRap = base + posBuff + negBuff\n    return effectiveRap\nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_unit"] = true,
						["use_strength"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["ownOnly"] = true,
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_form"] = false,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Stance/Form/Aura",
						["use_unit"] = true,
						["unevent"] = "auto",
						["type"] = "status",
						["use_inverse"] = true,
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["form"] = {
							["multi"] = {
								nil, -- [1]
								true, -- [2]
								true, -- [3]
								true, -- [4]
							},
						},
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
			},
			["desc"] = "Total Armor",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["HUNTER"] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["automaticWidth"] = "Auto",
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "远程攻强",
			["fixedWidth"] = 200,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["config"] = {
			},
			["uid"] = "buktAHdiyCx",
			["color"] = {
				1, -- [1]
				0.92549019607843, -- [2]
				0.67843137254902, -- [3]
				1, -- [4]
			},
			["xOffset"] = 0,
			["conditions"] = {
			},
			["selfPoint"] = "BOTTOM",
			["wordWrap"] = "WordWrap",
		},
		["物理命中"] = {
			["outline"] = "THICKOUTLINE",
			["authorOptions"] = {
			},
			["displayText"] = "物理命中: %c%",
			["customText"] = "function()\n    local crit = GetHitModifier()\n    return (\"%.1f\"):format(crit)\n    \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Conditions",
						["subeventPrefix"] = "SPELL",
						["use_unit"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["use_strength"] = true,
						["unit"] = "player",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["dodgepercent"] = "0",
						["duration"] = "1",
						["event"] = "Character Stats",
						["subeventPrefix"] = "SPELL",
						["use_dodgepercent"] = false,
						["subeventSuffix"] = "_CAST_START",
						["use_unit"] = true,
						["unit"] = "player",
						["dodgepercent_operator"] = ">",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "status",
						["subeventSuffix"] = "_CAST_START",
						["use_inverse"] = false,
						["event"] = "Stance/Form/Aura",
						["subeventPrefix"] = "SPELL",
						["use_spellName"] = true,
						["unevent"] = "auto",
						["use_form"] = false,
						["form"] = {
							["single"] = 3,
							["multi"] = {
								[3] = true,
							},
						},
						["unit"] = "player",
						["duration"] = "1",
						["use_unit"] = true,
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["wordWrap"] = "WordWrap",
			["desc"] = "Current Melee Crit Rating",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["HUNTER"] = true,
						["WARRIOR"] = true,
						["ROGUE"] = true,
						["DRUID"] = true,
						["SHAMAN"] = true,
						["PALADIN"] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["justify"] = "LEFT",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["parent"] = "角色属性",
			["semver"] = "1.0.3",
			["tocversion"] = 11302,
			["id"] = "物理命中",
			["fixedWidth"] = 200,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["config"] = {
			},
			["uid"] = "HAOvwoPyyRr",
			["color"] = {
				1, -- [1]
				0.980392156862745, -- [2]
				0.968627450980392, -- [3]
				1, -- [4]
			},
			["xOffset"] = 0,
			["conditions"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
			},
			["selfPoint"] = "BOTTOM",
		},
		["+ Healing "] = {
			["outline"] = "THICKOUTLINE",
			["authorOptions"] = {
			},
			["displayText"] = "治疗效果:+%c",
			["customText"] = "function()\n    local bonusHeal  = GetSpellBonusHealing();\n    return (\"%.f\"):format(bonusHeal)\n    \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_strength"] = true,
						["debuffType"] = "HELPFUL",
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["use_unit"] = true,
						["names"] = {
						},
						["buffShowOn"] = "showOnActive",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_form"] = false,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Stance/Form/Aura",
						["subeventPrefix"] = "SPELL",
						["unevent"] = "auto",
						["type"] = "status",
						["form"] = {
							["multi"] = {
								true, -- [1]
								true, -- [2]
								true, -- [3]
								true, -- [4]
							},
						},
						["unit"] = "player",
						["use_unit"] = true,
						["use_inverse"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["wordWrap"] = "WordWrap",
			["desc"] = "Current Bonus Healing",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["talent"] = {
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["SHAMAN"] = true,
						["DRUID"] = true,
						["PALADIN"] = true,
						["PRIEST"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["xOffset"] = 0,
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "+ Healing ",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["selfPoint"] = "BOTTOM",
			["uid"] = "cqsalGfD6kR",
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
			},
			["config"] = {
			},
			["fixedWidth"] = 200,
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["color"] = {
				0.52156862745098, -- [1]
				1, -- [2]
				0.51372549019608, -- [3]
				1, -- [4]
			},
		},
		["Block Chance"] = {
			["outline"] = "THICKOUTLINE",
			["xOffset"] = 0,
			["displayText"] = "格挡: %c%",
			["customText"] = "function()\n    local block = GetBlockChance()\n    return (\"%.1f\"):format(block)\n    \nend\n\n\n",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_strength"] = true,
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["unit"] = "player",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "status",
						["unevent"] = "auto",
						["blockpercent_operator"] = ">",
						["duration"] = "1",
						["event"] = "Character Stats",
						["unit"] = "player",
						["use_blockpercent"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_unit"] = true,
						["blockpercent"] = "0",
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["wordWrap"] = "WordWrap",
			["desc"] = "Current Block Chance",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["WARRIOR"] = true,
						["PALADIN"] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "Block Chance",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "QUaoMdhyGeK",
			["config"] = {
			},
			["authorOptions"] = {
			},
			["color"] = {
				0.74117647058823, -- [1]
				0.74117647058823, -- [2]
				0.67843137254902, -- [3]
				1, -- [4]
			},
			["fixedWidth"] = 200,
			["selfPoint"] = "BOTTOM",
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
		},
		["远程暴击"] = {
			["outline"] = "THICKOUTLINE",
			["color"] = {
				0, -- [1]
				1, -- [2]
				0.0117647058823529, -- [3]
				1, -- [4]
			},
			["displayText"] = "远程暴击: %c%",
			["customText"] = "function()\n    local crit = GetRangedCritChance()\n    return (\"%.1f\"):format(crit)\n    \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Conditions",
						["names"] = {
						},
						["use_strength"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["selfPoint"] = "BOTTOM",
			["desc"] = "Current Spell Crit Rating",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["HUNTER"] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["justify"] = "LEFT",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["parent"] = "角色属性",
			["semver"] = "1.0.3",
			["tocversion"] = 11302,
			["id"] = "远程暴击",
			["fixedWidth"] = 200,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["config"] = {
			},
			["uid"] = "Sx)31jG1aOu",
			["xOffset"] = 0,
			["authorOptions"] = {
			},
			["conditions"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
			},
			["wordWrap"] = "WordWrap",
		},
		["Armor Reduction % (DR)"] = {
			["outline"] = "THICKOUTLINE",
			["xOffset"] = 0,
			["displayText"] = "物理免伤:%c",
			["customText"] = "function()\n    if C_PaperDollInfo and C_PaperDollInfo.GetArmorEffectiveness then\n        local _,effectiveArmor = UnitArmor('player')\n        local lvl = UnitLevel('player')\n        local armorDR =  C_PaperDollInfo.GetArmorEffectiveness(effectiveArmor, lvl)\n        local armorDRvsTarget = C_PaperDollInfo.GetArmorEffectivenessAgainstTarget(effectiveArmor)\n        \n        if (armorDRvsTarget == nil) then \n            armorDRvsTarget = 0\n        end\n        \n        return (\"%0.1f%%\"):format( armorDR*100 or 0, armorDRvsTarget*100 or 0)\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_strength"] = true,
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["unit"] = "player",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_form"] = false,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Stance/Form/Aura",
						["subeventPrefix"] = "SPELL",
						["unevent"] = "auto",
						["type"] = "status",
						["form"] = {
							["multi"] = {
								nil, -- [1]
								true, -- [2]
								true, -- [3]
								true, -- [4]
							},
						},
						["unit"] = "player",
						["use_unit"] = true,
						["use_inverse"] = true,
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["selfPoint"] = "BOTTOM",
			["desc"] = "Armor Reduction % (DR)",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["WARRIOR"] = true,
						["DRUID"] = true,
						["PALADIN"] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "Armor Reduction % (DR)",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "hr8K1BbBBni",
			["config"] = {
			},
			["color"] = {
				1, -- [1]
				0.92549019607843, -- [2]
				0.67843137254902, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["fixedWidth"] = 200,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
			},
			["wordWrap"] = "WordWrap",
		},
		["攻强"] = {
			["outline"] = "THICKOUTLINE",
			["color"] = {
				1, -- [1]
				0.92549019607843, -- [2]
				0.67843137254902, -- [3]
				1, -- [4]
			},
			["displayText"] = "攻击强度:%c",
			["customText"] = "function()\n    local base,posBuff,negBuff = UnitAttackPower(\"player\")\n    local effectiveAp = base + posBuff + negBuff\n    return effectiveAp\nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Conditions",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["ownOnly"] = true,
						["use_strength"] = true,
						["use_unit"] = true,
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_form"] = false,
						["subeventSuffix"] = "_CAST_START",
						["use_inverse"] = true,
						["event"] = "Stance/Form/Aura",
						["use_unit"] = true,
						["unevent"] = "auto",
						["type"] = "status",
						["duration"] = "1",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["form"] = {
							["multi"] = {
								nil, -- [1]
								true, -- [2]
								true, -- [3]
								true, -- [4]
							},
						},
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["selfPoint"] = "BOTTOM",
			["desc"] = "Total Armor",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["HUNTER"] = true,
						["WARRIOR"] = true,
						["PALADIN"] = true,
						["DRUID"] = true,
						["SHAMAN"] = true,
						["ROGUE"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["justify"] = "LEFT",
			["authorOptions"] = {
			},
			["parent"] = "角色属性",
			["semver"] = "1.0.3",
			["tocversion"] = 11302,
			["id"] = "攻强",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 0,
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
			["uid"] = "8g45pgiXFn1",
			["fixedWidth"] = 200,
			["wordWrap"] = "WordWrap",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
		},
		["Total Armor"] = {
			["outline"] = "THICKOUTLINE",
			["authorOptions"] = {
			},
			["displayText"] = "护甲值:%c",
			["customText"] = "function()\n    return select(2, UnitArmor(\"player\"))\nend \n\n",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_unit"] = true,
						["use_strength"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["ownOnly"] = true,
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_form"] = false,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Stance/Form/Aura",
						["use_unit"] = true,
						["subeventSuffix"] = "_CAST_START",
						["type"] = "status",
						["use_inverse"] = true,
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["form"] = {
							["multi"] = {
								nil, -- [1]
								true, -- [2]
								true, -- [3]
								true, -- [4]
							},
						},
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["wordWrap"] = "WordWrap",
			["desc"] = "Total Armor",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["WARRIOR"] = true,
						["DRUID"] = true,
						["PALADIN"] = true,
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["semver"] = "1.0.3",
			["xOffset"] = 0,
			["parent"] = "角色属性",
			["justify"] = "LEFT",
			["tocversion"] = 11302,
			["id"] = "Total Armor",
			["fixedWidth"] = 200,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["color"] = {
				1, -- [1]
				0.92549019607843, -- [2]
				0.67843137254902, -- [3]
				1, -- [4]
			},
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["duration_type"] = "seconds",
					["preset"] = "fade",
				},
			},
			["uid"] = "6CbTWHSQnYz",
			["conditions"] = {
			},
			["selfPoint"] = "BOTTOM",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
		},
		["Parry Chance"] = {
			["outline"] = "THICKOUTLINE",
			["color"] = {
				0.74117647058823, -- [1]
				0.74117647058823, -- [2]
				0.67843137254902, -- [3]
				1, -- [4]
			},
			["displayText"] = "招架: %c%",
			["customText"] = "function()\n    local parry = GetParryChance()\n    return (\"%.1f\"):format(parry)\n    \nend",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/Bu9rVLe2l/4",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "status",
						["use_alwaystrue"] = true,
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_strength"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["use_parrypercent"] = true,
						["parrypercent_operator"] = ">",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Character Stats",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["type"] = "status",
						["use_unit"] = true,
						["unit"] = "player",
						["parrypercent"] = "0",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["wordWrap"] = "WordWrap",
			["desc"] = "Current Parry Chance",
			["font"] = "PT Sans Narrow",
			["version"] = 4,
			["subRegions"] = {
			},
			["load"] = {
				["use_class"] = false,
				["use_never"] = false,
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["WARRIOR"] = true,
						["PALADIN"] = true,
						["ROGUE"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 17,
			["regionType"] = "text",
			["justify"] = "LEFT",
			["authorOptions"] = {
			},
			["parent"] = "角色属性",
			["semver"] = "1.0.3",
			["tocversion"] = 11302,
			["id"] = "Parry Chance",
			["fixedWidth"] = 200,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 0,
			["uid"] = "aKDDpnKv1b9",
			["selfPoint"] = "BOTTOM",
			["config"] = {
			},
			["conditions"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
			["automaticWidth"] = "Auto",
		},
	},
	["minimap"] = {
		["minimapPos"] = 232.201880231053,
		["hide"] = false,
	},
	["history"] = {
		["aKDDpnKv1b9"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["xOffset"] = 0,
				["displayText"] = "招架: %c%",
				["customText"] = "function()\n    local parry = GetParryChance()\n    return (\"%.1f\"):format(parry)\n    \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_strength"] = true,
							["names"] = {
							},
							["spellIds"] = {
							},
							["subeventPrefix"] = "SPELL",
							["unit"] = "player",
							["use_unit"] = true,
							["unevent"] = "auto",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["use_parrypercent"] = true,
							["type"] = "status",
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Character Stats",
							["subeventPrefix"] = "SPELL",
							["unevent"] = "auto",
							["unit"] = "player",
							["use_unit"] = true,
							["parrypercent_operator"] = ">",
							["parrypercent"] = "0",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["wordWrap"] = "WordWrap",
				["desc"] = "Current Parry Chance",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["WARRIOR"] = true,
							["ROGUE"] = true,
							["PALADIN"] = true,
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
				["authorOptions"] = {
				},
				["justify"] = "LEFT",
				["tocversion"] = 11302,
				["id"] = "Parry Chance",
				["conditions"] = {
				},
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["config"] = {
				},
				["uid"] = "aKDDpnKv1b9",
				["selfPoint"] = "BOTTOM",
				["color"] = {
					0.74117647058823, -- [1]
					0.74117647058823, -- [2]
					0.67843137254902, -- [3]
					1, -- [4]
				},
				["parent"] = "角色属性",
				["fixedWidth"] = 200,
				["semver"] = "1.0.3",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
			},
		},
		["NEksuYBgIV1"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["color"] = {
					0.74117647058823, -- [1]
					0.74117647058823, -- [2]
					0.67843137254902, -- [3]
					1, -- [4]
				},
				["displayText"] = "Mp5: %c",
				["customText"] = "function()\n    local base, casting = GetManaRegen('player') * 4.99\n    return (\"%.f\"):format(base, casting) \n    \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_strength"] = true,
							["names"] = {
							},
							["spellIds"] = {
							},
							["subeventPrefix"] = "SPELL",
							["unit"] = "player",
							["use_unit"] = true,
							["unevent"] = "auto",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["form"] = {
								["multi"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
								},
							},
							["event"] = "Stance/Form/Aura",
							["unit"] = "player",
							["use_inverse"] = true,
							["subeventPrefix"] = "SPELL",
							["duration"] = "1",
							["subeventSuffix"] = "_CAST_START",
							["use_unit"] = true,
							["use_form"] = false,
							["use_resting"] = false,
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
				},
				["desc"] = "Current Mana Per 5 Seconds",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["PRIEST"] = true,
							["DRUID"] = true,
							["PALADIN"] = true,
							["SHAMAN"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["selfPoint"] = "BOTTOM",
				["authorOptions"] = {
				},
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "Mp5",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["uid"] = "NEksuYBgIV1",
				["config"] = {
				},
				["wordWrap"] = "WordWrap",
				["xOffset"] = 0,
				["parent"] = "角色属性",
				["conditions"] = {
				},
				["justify"] = "LEFT",
				["automaticWidth"] = "Auto",
			},
		},
		["UR)w6Pb4UKM"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["arcLength"] = 360,
				["controlledChildren"] = {
				},
				["borderBackdrop"] = "Blizzard Tooltip",
				["xOffset"] = -758.119284213137,
				["yOffset"] = -729.00420382489,
				["anchorPoint"] = "CENTER",
				["borderColor"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["rowSpace"] = 1,
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["debuffType"] = "HELPFUL",
							["type"] = "aura2",
							["spellIds"] = {
							},
							["subeventSuffix"] = "_CAST_START",
							["subeventPrefix"] = "SPELL",
							["unit"] = "player",
							["event"] = "Health",
							["names"] = {
							},
						},
						["untrigger"] = {
						},
					}, -- [1]
				},
				["columnSpace"] = 1,
				["radius"] = 200,
				["animation"] = {
					["start"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
				},
				["align"] = "LEFT",
				["desc"] = "Character Stat Display",
				["rotation"] = 0,
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["class"] = {
						["multi"] = {
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["backdropColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["animate"] = true,
				["scale"] = 0.75,
				["selfPoint"] = "BOTTOMLEFT",
				["border"] = false,
				["borderEdge"] = "1 Pixel",
				["regionType"] = "dynamicgroup",
				["borderSize"] = 2,
				["limit"] = 6,
				["space"] = 3,
				["gridType"] = "RD",
				["useAnchorPerUnit"] = false,
				["uid"] = "UR)w6Pb4UKM",
				["constantFactor"] = "RADIUS",
				["frameStrata"] = 1,
				["borderOffset"] = 4,
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "角色属性",
				["borderInset"] = 1,
				["gridWidth"] = 5,
				["anchorFrameType"] = "SCREEN",
				["internalVersion"] = 24,
				["config"] = {
				},
				["sort"] = "descending",
				["authorOptions"] = {
				},
				["grow"] = "UP",
				["conditions"] = {
				},
				["useLimit"] = false,
				["stagger"] = 0,
			},
		},
		["Sx)31jG1aOu"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["parent"] = "角色属性",
				["displayText"] = "远程暴击: %c%",
				["customText"] = "function()\n    local crit = GetRangedCritChance()\n    return (\"%.1f\"):format(crit)\n    \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["init"] = {
					},
					["finish"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Conditions",
							["names"] = {
							},
							["use_strength"] = true,
							["spellIds"] = {
							},
							["subeventPrefix"] = "SPELL",
							["unit"] = "player",
							["use_unit"] = true,
							["unevent"] = "auto",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["selfPoint"] = "BOTTOM",
				["desc"] = "Current Spell Crit Rating",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["HUNTER"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
				},
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["justify"] = "LEFT",
				["tocversion"] = 11302,
				["id"] = "远程暴击",
				["conditions"] = {
				},
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["authorOptions"] = {
				},
				["config"] = {
				},
				["xOffset"] = 0,
				["color"] = {
					0, -- [1]
					1, -- [2]
					0.0117647058823529, -- [3]
					1, -- [4]
				},
				["uid"] = "Sx)31jG1aOu",
				["fixedWidth"] = 200,
				["semver"] = "1.0.3",
				["wordWrap"] = "WordWrap",
			},
		},
		["hr8K1BbBBni"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["parent"] = "角色属性",
				["displayText"] = "物理免伤:%c",
				["customText"] = "function()\n    if C_PaperDollInfo and C_PaperDollInfo.GetArmorEffectiveness then\n        local _,effectiveArmor = UnitArmor('player')\n        local lvl = UnitLevel('player')\n        local armorDR =  C_PaperDollInfo.GetArmorEffectiveness(effectiveArmor, lvl)\n        local armorDRvsTarget = C_PaperDollInfo.GetArmorEffectivenessAgainstTarget(effectiveArmor)\n        \n        if (armorDRvsTarget == nil) then \n            armorDRvsTarget = 0\n        end\n        \n        return (\"%0.1f%%\"):format( armorDR*100 or 0, armorDRvsTarget*100 or 0)\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_strength"] = true,
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["names"] = {
							},
							["unit"] = "player",
							["use_unit"] = true,
							["unevent"] = "auto",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Stance/Form/Aura",
							["subeventPrefix"] = "SPELL",
							["use_inverse"] = true,
							["use_unit"] = true,
							["unit"] = "player",
							["form"] = {
								["multi"] = {
									nil, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
								},
							},
							["use_form"] = false,
							["subeventSuffix"] = "_CAST_START",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["selfPoint"] = "BOTTOM",
				["desc"] = "Armor Reduction % (DR)",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["WARRIOR"] = true,
							["DRUID"] = true,
							["PALADIN"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
				},
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "Armor Reduction % (DR)",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["authorOptions"] = {
				},
				["uid"] = "hr8K1BbBBni",
				["color"] = {
					1, -- [1]
					0.92549019607843, -- [2]
					0.67843137254902, -- [3]
					1, -- [4]
				},
				["xOffset"] = 0,
				["config"] = {
				},
				["conditions"] = {
				},
				["justify"] = "LEFT",
				["wordWrap"] = "WordWrap",
			},
		},
		["KrsFyQA04Nx"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["xOffset"] = 0,
				["displayText"] = "冰霜伤害: +%c",
				["customText"] = "-- Change out the number in the first line to track your desired spell type.\n--\n-- example: GetSpellBonusDamage(6) to track Shadow damage.\n--\n-- 1 for Physical\n-- 2 for Holy\n-- 3 for Fire\n-- 4 for Nature\n-- 5 for Frost  (default)\n-- 6 for Shadow\n-- 7 for Arcane\n--\n-----------------------------------------------------------------\n\nfunction ()\n    local spellDmg = GetSpellBonusDamage(5)\n    return (\"%.f\"):format(spellDmg)\n    \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_strength"] = true,
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["names"] = {
							},
							["unit"] = "player",
							["use_unit"] = true,
							["unevent"] = "auto",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
				["desc"] = "Current Bonus Spell Damage",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["MAGE"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["selfPoint"] = "BOTTOM",
				["authorOptions"] = {
				},
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "冰霜伤害",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["uid"] = "KrsFyQA04Nx",
				["config"] = {
				},
				["wordWrap"] = "WordWrap",
				["color"] = {
					0, -- [1]
					0.835294117647059, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["parent"] = "角色属性",
				["conditions"] = {
					{
						["check"] = {
						},
						["changes"] = {
							{
							}, -- [1]
						},
					}, -- [1]
				},
				["justify"] = "LEFT",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
			},
		},
		["VTVgLILakZ)"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["authorOptions"] = {
				},
				["displayText"] = "火焰伤害: +%c",
				["customText"] = "-- Change out the number in the first line to track your desired spell type.\n--\n-- example: GetSpellBonusDamage(6) to track Shadow damage.\n--\n-- 1 for Physical\n-- 2 for Holy\n-- 3 for Fire\n-- 4 for Nature\n-- 5 for Frost  (default)\n-- 6 for Shadow\n-- 7 for Arcane\n--\n-----------------------------------------------------------------\n\nfunction ()\n    local spellDmg = GetSpellBonusDamage(3)\n    return (\"%.f\"):format(spellDmg)\n    \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["init"] = {
					},
					["finish"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_strength"] = true,
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["names"] = {
							},
							["unit"] = "player",
							["use_unit"] = true,
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["selfPoint"] = "BOTTOM",
				["desc"] = "Current Bonus Spell Damage",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["MAGE"] = true,
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
				},
				["xOffset"] = 0,
				["justify"] = "LEFT",
				["tocversion"] = 11302,
				["id"] = "火焰伤害",
				["conditions"] = {
					{
						["check"] = {
						},
						["changes"] = {
							{
							}, -- [1]
						},
					}, -- [1]
				},
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["uid"] = "VTVgLILakZ)",
				["config"] = {
				},
				["wordWrap"] = "WordWrap",
				["color"] = {
					0.937254901960784, -- [1]
					0.290196078431373, -- [2]
					0.0627450980392157, -- [3]
					1, -- [4]
				},
				["parent"] = "角色属性",
				["fixedWidth"] = 200,
				["semver"] = "1.0.3",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
			},
		},
		["QUaoMdhyGeK"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["parent"] = "角色属性",
				["displayText"] = "格挡: %c%",
				["customText"] = "function()\n    local block = GetBlockChance()\n    return (\"%.1f\"):format(block)\n    \nend\n\n\n",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_strength"] = true,
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["names"] = {
							},
							["unit"] = "player",
							["use_unit"] = true,
							["unevent"] = "auto",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["blockpercent_operator"] = ">",
							["duration"] = "1",
							["event"] = "Character Stats",
							["unit"] = "player",
							["subeventPrefix"] = "SPELL",
							["subeventSuffix"] = "_CAST_START",
							["use_unit"] = true,
							["blockpercent"] = "0",
							["use_blockpercent"] = true,
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["wordWrap"] = "WordWrap",
				["desc"] = "Current Block Chance",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["PALADIN"] = true,
							["WARRIOR"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["selfPoint"] = "BOTTOM",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "Block Chance",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["color"] = {
					0.74117647058823, -- [1]
					0.74117647058823, -- [2]
					0.67843137254902, -- [3]
					1, -- [4]
				},
				["uid"] = "QUaoMdhyGeK",
				["authorOptions"] = {
				},
				["xOffset"] = 0,
				["config"] = {
				},
				["conditions"] = {
				},
				["justify"] = "LEFT",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
			},
		},
		["6CbTWHSQnYz"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["color"] = {
					1, -- [1]
					0.92549019607843, -- [2]
					0.67843137254902, -- [3]
					1, -- [4]
				},
				["displayText"] = "护甲值:%c",
				["customText"] = "function()\n    return select(2, UnitArmor(\"player\"))\nend \n\n",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_unit"] = true,
							["use_strength"] = true,
							["names"] = {
							},
							["spellIds"] = {
							},
							["subeventPrefix"] = "SPELL",
							["unit"] = "player",
							["ownOnly"] = true,
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Stance/Form/Aura",
							["use_unit"] = true,
							["form"] = {
								["multi"] = {
									nil, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
								},
							},
							["subeventPrefix"] = "SPELL",
							["unit"] = "player",
							["use_inverse"] = true,
							["use_form"] = false,
							["unevent"] = "auto",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["wordWrap"] = "WordWrap",
				["desc"] = "Total Armor",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["WARRIOR"] = true,
							["DRUID"] = true,
							["PALADIN"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["selfPoint"] = "BOTTOM",
				["xOffset"] = 0,
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "Total Armor",
				["conditions"] = {
				},
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["uid"] = "6CbTWHSQnYz",
				["config"] = {
				},
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
				},
				["authorOptions"] = {
				},
				["parent"] = "角色属性",
				["fixedWidth"] = 200,
				["justify"] = "LEFT",
				["automaticWidth"] = "Auto",
			},
		},
		["agj5G(lnN1f"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["authorOptions"] = {
				},
				["displayText"] = "法术命中: %c%",
				["customText"] = "function()\n    local crit = GetSpellHitModifier()\n    return (\"%.1f\"):format(crit)\n    \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_strength"] = true,
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["names"] = {
							},
							["unit"] = "player",
							["use_unit"] = true,
							["unevent"] = "auto",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["dodgepercent"] = "0",
							["duration"] = "1",
							["event"] = "Character Stats",
							["subeventPrefix"] = "SPELL",
							["use_dodgepercent"] = false,
							["subeventSuffix"] = "_CAST_START",
							["use_unit"] = true,
							["unit"] = "player",
							["dodgepercent_operator"] = ">",
						},
						["untrigger"] = {
						},
					}, -- [2]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Stance/Form/Aura",
							["use_unit"] = true,
							["use_spellName"] = true,
							["unit"] = "player",
							["use_inverse"] = false,
							["subeventPrefix"] = "SPELL",
							["form"] = {
								["single"] = 3,
								["multi"] = {
									[3] = true,
								},
							},
							["use_form"] = false,
							["subeventSuffix"] = "_CAST_START",
						},
						["untrigger"] = {
						},
					}, -- [3]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["selfPoint"] = "BOTTOM",
				["desc"] = "Current Melee Crit Rating",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["WARLOCK"] = true,
							["SHAMAN"] = true,
							["MAGE"] = true,
							["DRUID"] = true,
							["PRIEST"] = true,
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
				["color"] = {
					1, -- [1]
					0.996078431372549, -- [2]
					0.992156862745098, -- [3]
					1, -- [4]
				},
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "法术命中",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["uid"] = "agj5G(lnN1f",
				["config"] = {
				},
				["wordWrap"] = "WordWrap",
				["xOffset"] = 0,
				["parent"] = "角色属性",
				["conditions"] = {
				},
				["justify"] = "LEFT",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
			},
		},
		["COCSxmbhdg8"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["color"] = {
					1, -- [1]
					0.6156862745098, -- [2]
					0.50588235294118, -- [3]
					1, -- [4]
				},
				["displayText"] = "力量:%c",
				["customText"] = "function(unit, cache, textframe)\n    local strength = UnitStat(\"player\", 1)\n    \n    return (\" %.f\"):format(strength)\nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Conditions",
							["names"] = {
							},
							["use_strength"] = true,
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["use_unit"] = true,
							["unit"] = "player",
							["ownOnly"] = true,
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Stance/Form/Aura",
							["subeventPrefix"] = "SPELL",
							["use_inverse"] = true,
							["unit"] = "player",
							["use_unit"] = true,
							["form"] = {
								["multi"] = {
									[4] = true,
								},
							},
							["use_form"] = false,
							["unevent"] = "auto",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
				["desc"] = "Current Strength",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["WARRIOR"] = true,
							["PALADIN"] = true,
							["ROGUE"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["selfPoint"] = "BOTTOM",
				["xOffset"] = 0,
				["justify"] = "LEFT",
				["tocversion"] = 11302,
				["id"] = "Strength",
				["conditions"] = {
				},
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["uid"] = "COCSxmbhdg8",
				["config"] = {
				},
				["wordWrap"] = "WordWrap",
				["authorOptions"] = {
				},
				["parent"] = "角色属性",
				["fixedWidth"] = 200,
				["semver"] = "1.0.3",
				["automaticWidth"] = "Auto",
			},
		},
		["NNvCHW7F3xu"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["parent"] = "角色属性",
				["displayText"] = "耐力:%c",
				["customText"] = "function(unit, cache, textframe)\n    local stamina = UnitStat(\"player\", 3)\n    \n    return (\" %.f\"):format(stamina)\nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Conditions",
							["names"] = {
							},
							["use_strength"] = true,
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["use_unit"] = true,
							["unit"] = "player",
							["ownOnly"] = true,
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Stance/Form/Aura",
							["subeventPrefix"] = "SPELL",
							["use_inverse"] = true,
							["use_unit"] = true,
							["unit"] = "player",
							["form"] = {
								["multi"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
								},
							},
							["use_form"] = false,
							["subeventSuffix"] = "_CAST_START",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["wordWrap"] = "WordWrap",
				["desc"] = "Current Stamina",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["MAGE"] = true,
							["DRUID"] = true,
							["ROGUE"] = true,
						},
					},
					["use_never"] = false,
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["selfPoint"] = "BOTTOM",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "Stamina",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["color"] = {
					0.97647058823529, -- [1]
					1, -- [2]
					0.85098039215686, -- [3]
					1, -- [4]
				},
				["uid"] = "NNvCHW7F3xu",
				["authorOptions"] = {
				},
				["xOffset"] = 0,
				["config"] = {
				},
				["conditions"] = {
				},
				["justify"] = "LEFT",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
			},
		},
		["VDDHrvlJqXk"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["color"] = {
					0.37254901960784, -- [1]
					1, -- [2]
					0.96470588235294, -- [3]
					1, -- [4]
				},
				["displayText"] = "法术暴击: %c%",
				["customText"] = "function()\n    local crit = GetSpellCritChance()\n    return (\"%.1f\"):format(crit)\n    \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_strength"] = true,
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["names"] = {
							},
							["unit"] = "player",
							["use_unit"] = true,
							["unevent"] = "auto",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["selfPoint"] = "BOTTOM",
				["desc"] = "Current Spell Crit Rating",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["WARLOCK"] = true,
							["SHAMAN"] = true,
							["MAGE"] = true,
							["DRUID"] = true,
							["PRIEST"] = true,
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["authorOptions"] = {
				},
				["semver"] = "1.0.3",
				["justify"] = "LEFT",
				["tocversion"] = 11302,
				["id"] = "Spell Crit",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["config"] = {
				},
				["uid"] = "VDDHrvlJqXk",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
				["xOffset"] = 0,
				["parent"] = "角色属性",
				["conditions"] = {
				},
				["automaticWidth"] = "Auto",
				["wordWrap"] = "WordWrap",
			},
		},
		["buktAHdiyCx"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["parent"] = "角色属性",
				["displayText"] = "远程攻强:%c",
				["customText"] = "function()\n    local base,posBuff,negBuff = UnitRangedAttackPower(\"player\")\n    local effectiveRap = base + posBuff + negBuff\n    return effectiveRap\nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_unit"] = true,
							["use_strength"] = true,
							["names"] = {
							},
							["spellIds"] = {
							},
							["subeventPrefix"] = "SPELL",
							["unit"] = "player",
							["ownOnly"] = true,
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Stance/Form/Aura",
							["use_unit"] = true,
							["form"] = {
								["multi"] = {
									nil, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
								},
							},
							["subeventPrefix"] = "SPELL",
							["unit"] = "player",
							["use_inverse"] = true,
							["use_form"] = false,
							["subeventSuffix"] = "_CAST_START",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
				},
				["desc"] = "Total Armor",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["HUNTER"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["selfPoint"] = "BOTTOM",
				["automaticWidth"] = "Auto",
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "远程攻强",
				["conditions"] = {
				},
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["xOffset"] = 0,
				["config"] = {
				},
				["color"] = {
					1, -- [1]
					0.92549019607843, -- [2]
					0.67843137254902, -- [3]
					1, -- [4]
				},
				["authorOptions"] = {
				},
				["uid"] = "buktAHdiyCx",
				["fixedWidth"] = 200,
				["justify"] = "LEFT",
				["wordWrap"] = "WordWrap",
			},
		},
		["HAOvwoPyyRr"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["parent"] = "角色属性",
				["displayText"] = "物理命中: %c%",
				["customText"] = "function()\n    local crit = GetHitModifier()\n    return (\"%.1f\"):format(crit)\n    \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["init"] = {
					},
					["finish"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Conditions",
							["subeventPrefix"] = "SPELL",
							["use_unit"] = true,
							["spellIds"] = {
							},
							["names"] = {
							},
							["unit"] = "player",
							["use_strength"] = true,
							["unevent"] = "auto",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["dodgepercent"] = "0",
							["duration"] = "1",
							["event"] = "Character Stats",
							["subeventPrefix"] = "SPELL",
							["use_dodgepercent"] = false,
							["subeventSuffix"] = "_CAST_START",
							["unit"] = "player",
							["use_unit"] = true,
							["dodgepercent_operator"] = ">",
						},
						["untrigger"] = {
						},
					}, -- [2]
					{
						["trigger"] = {
							["type"] = "status",
							["subeventSuffix"] = "_CAST_START",
							["use_inverse"] = false,
							["event"] = "Stance/Form/Aura",
							["subeventPrefix"] = "SPELL",
							["use_spellName"] = true,
							["use_unit"] = true,
							["duration"] = "1",
							["unit"] = "player",
							["form"] = {
								["single"] = 3,
								["multi"] = {
									[3] = true,
								},
							},
							["use_form"] = false,
							["unevent"] = "auto",
						},
						["untrigger"] = {
						},
					}, -- [3]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["wordWrap"] = "WordWrap",
				["desc"] = "Current Melee Crit Rating",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["HUNTER"] = true,
							["WARRIOR"] = true,
							["ROGUE"] = true,
							["DRUID"] = true,
							["PALADIN"] = true,
							["SHAMAN"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
				},
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["justify"] = "LEFT",
				["tocversion"] = 11302,
				["id"] = "物理命中",
				["conditions"] = {
				},
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["xOffset"] = 0,
				["config"] = {
				},
				["color"] = {
					1, -- [1]
					0.980392156862745, -- [2]
					0.968627450980392, -- [3]
					1, -- [4]
				},
				["authorOptions"] = {
				},
				["uid"] = "HAOvwoPyyRr",
				["fixedWidth"] = 200,
				["semver"] = "1.0.3",
				["selfPoint"] = "BOTTOM",
			},
		},
		["cqsalGfD6kR"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["color"] = {
					0.52156862745098, -- [1]
					1, -- [2]
					0.51372549019608, -- [3]
					1, -- [4]
				},
				["displayText"] = "治疗效果:+%c",
				["customText"] = "function()\n    local bonusHeal  = GetSpellBonusHealing();\n    return (\"%.f\"):format(bonusHeal)\n    \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_strength"] = true,
							["buffShowOn"] = "showOnActive",
							["names"] = {
							},
							["spellIds"] = {
							},
							["use_unit"] = true,
							["subeventPrefix"] = "SPELL",
							["unit"] = "player",
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Stance/Form/Aura",
							["subeventPrefix"] = "SPELL",
							["use_inverse"] = true,
							["use_unit"] = true,
							["unit"] = "player",
							["form"] = {
								["multi"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
								},
							},
							["use_form"] = false,
							["subeventSuffix"] = "_CAST_START",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "all",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["selfPoint"] = "BOTTOM",
				["desc"] = "Current Bonus Healing",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["talent"] = {
					},
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["PRIEST"] = true,
							["DRUID"] = true,
							["PALADIN"] = true,
							["SHAMAN"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["xOffset"] = 0,
				["semver"] = "1.0.3",
				["justify"] = "LEFT",
				["tocversion"] = 11302,
				["id"] = "+ Healing ",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["config"] = {
				},
				["uid"] = "cqsalGfD6kR",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
				},
				["authorOptions"] = {
				},
				["parent"] = "角色属性",
				["conditions"] = {
				},
				["automaticWidth"] = "Auto",
				["wordWrap"] = "WordWrap",
			},
		},
		["WV4XBOmVLxN"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["authorOptions"] = {
				},
				["displayText"] = "暗影伤害: +%c",
				["customText"] = "-- Change out the number in the first line to track your desired spell type.\n--\n-- example: GetSpellBonusDamage(6) to track Shadow damage.\n--\n-- 1 for Physical\n-- 2 for Holy\n-- 3 for Fire\n-- 4 for Nature\n-- 5 for Frost  (default)\n-- 6 for Shadow\n-- 7 for Arcane\n--\n-----------------------------------------------------------------\n\nfunction ()\n    local spellDmg = GetSpellBonusDamage(6)\n    return (\"%.f\"):format(spellDmg)\n    \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["init"] = {
					},
					["finish"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_strength"] = true,
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["names"] = {
							},
							["unit"] = "player",
							["use_unit"] = true,
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["selfPoint"] = "BOTTOM",
				["desc"] = "Current Bonus Spell Damage",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["WARLOCK"] = true,
							["PRIEST"] = true,
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "preset",
						["preset"] = "fade",
						["duration_type"] = "seconds",
					},
				},
				["xOffset"] = 0,
				["justify"] = "LEFT",
				["tocversion"] = 11302,
				["id"] = "暗影伤害",
				["conditions"] = {
					{
						["check"] = {
						},
						["changes"] = {
							{
							}, -- [1]
						},
					}, -- [1]
				},
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["uid"] = "WV4XBOmVLxN",
				["config"] = {
				},
				["wordWrap"] = "WordWrap",
				["color"] = {
					0.431372549019608, -- [1]
					0.368627450980392, -- [2]
					0.63921568627451, -- [3]
					1, -- [4]
				},
				["parent"] = "角色属性",
				["fixedWidth"] = 200,
				["semver"] = "1.0.3",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
			},
		},
		["KLvuhGf3x1K"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["parent"] = "角色属性",
				["displayText"] = "精神:%c",
				["customText"] = "function(unit, cache, textframe)\n    local spirit = UnitStat(\"player\", 5)\n    \n    return (\" %.f\"):format(spirit)\nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Conditions",
							["subeventPrefix"] = "SPELL",
							["use_strength"] = true,
							["names"] = {
							},
							["spellIds"] = {
							},
							["use_unit"] = true,
							["unit"] = "player",
							["ownOnly"] = true,
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Stance/Form/Aura",
							["subeventPrefix"] = "SPELL",
							["use_inverse"] = true,
							["unit"] = "player",
							["use_unit"] = true,
							["form"] = {
								["multi"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
								},
							},
							["use_form"] = false,
							["unevent"] = "auto",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["wordWrap"] = "WordWrap",
				["desc"] = "Current Spirit",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["talent"] = {
					},
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["WARLOCK"] = true,
							["PALADIN"] = true,
							["MAGE"] = true,
							["DRUID"] = true,
							["SHAMAN"] = true,
							["PRIEST"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["selfPoint"] = "BOTTOM",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "Spirit",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["authorOptions"] = {
				},
				["uid"] = "KLvuhGf3x1K",
				["color"] = {
					0.650980392156863, -- [1]
					0.705882352941177, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["xOffset"] = 0,
				["config"] = {
				},
				["conditions"] = {
				},
				["justify"] = "LEFT",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
			},
		},
		["v4G5GkemoL)"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["parent"] = "角色属性",
				["displayText"] = "近战暴击: %c%",
				["customText"] = "function()\n    local crit = GetCritChance()\n    return (\"%.1f\"):format(crit)\n    \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_strength"] = true,
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["names"] = {
							},
							["unit"] = "player",
							["use_unit"] = true,
							["unevent"] = "auto",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["dodgepercent"] = "0",
							["duration"] = "1",
							["event"] = "Character Stats",
							["subeventPrefix"] = "SPELL",
							["use_dodgepercent"] = false,
							["subeventSuffix"] = "_CAST_START",
							["use_unit"] = true,
							["unit"] = "player",
							["dodgepercent_operator"] = ">",
						},
						["untrigger"] = {
						},
					}, -- [2]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Stance/Form/Aura",
							["use_unit"] = true,
							["use_spellName"] = true,
							["unit"] = "player",
							["use_inverse"] = false,
							["subeventPrefix"] = "SPELL",
							["form"] = {
								["single"] = 3,
								["multi"] = {
									[3] = true,
								},
							},
							["use_form"] = false,
							["subeventSuffix"] = "_CAST_START",
						},
						["untrigger"] = {
						},
					}, -- [3]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["wordWrap"] = "WordWrap",
				["desc"] = "Current Melee Crit Rating",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["HUNTER"] = true,
							["WARRIOR"] = true,
							["ROGUE"] = true,
							["DRUID"] = true,
							["SHAMAN"] = true,
							["PALADIN"] = true,
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "Melee Crit ",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["xOffset"] = 0,
				["uid"] = "v4G5GkemoL)",
				["color"] = {
					1, -- [1]
					0.74117647058823, -- [2]
					0.5921568627451, -- [3]
					1, -- [4]
				},
				["authorOptions"] = {
				},
				["config"] = {
				},
				["conditions"] = {
				},
				["justify"] = "LEFT",
				["selfPoint"] = "BOTTOM",
			},
		},
		["VsZ9OrDHT)B"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["parent"] = "角色属性",
				["displayText"] = "============\n宠物信息：\n%c\n============",
				["customText"] = "function()\n    \n    function round(number, decimals)\n        return ((\"%%.%df\"):format(decimals)):format(number)\n    end\n    \n    happiness, damagePercentage, loyaltyRate = GetPetHappiness()\n    if happiness then\n        if happiness == 3 then\n            level = \"|CFF20C000开心\"\n            damage = \"|CFF20C000\"..damagePercentage..\"%\"\n            rate = \"|CFF20C000\"..loyaltyRate\n        elseif happiness == 2 then\n            level = \"|CFFFE8A0E满足\"\n            damage = \"|CFFFE8A0E\"..damagePercentage..\"%\"\n            rate = \"|CFFFE8A0E\"..loyaltyRate\n        else\n            level = \"|CFFFF0303不满\"\n            damage = \"|CFFFF0303\"..damagePercentage..\"%\"\n            rate = \"|CFFFF0303\"..loyaltyRate\n        end\n        \n        currXP, nextXP = GetPetExperience()\n        local percent = round((currXP/nextXP)*100,0)\n        petLevel = UnitLevel(\"pet\")\n        \n        return \"状态: \"..level..\"|CFFFFFFFF\\n忠诚度: \"..rate..\"|CFFFFFFFF\\n伤害: \"..damage..\"|CFFFFFFFF\\n等级: \"..petLevel..\"\\n|CFFFFFFFF经验: |CFFFF0303\"..currXP..\"|CFFFFFFFF\\\\\"..nextXP..\" \"..percent..\"%\"\n    end        \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Fixed",
				["actions"] = {
					["start"] = {
					},
					["init"] = {
					},
					["finish"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["names"] = {
							},
							["ownOnly"] = true,
							["event"] = "Conditions",
							["use_strength"] = true,
							["duration"] = "1",
							["unit"] = "player",
							["spellIds"] = {
							},
							["use_unit"] = true,
							["subeventPrefix"] = "SPELL",
							["subeventSuffix"] = "_CAST_START",
							["use_HasPet"] = true,
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["form"] = {
								["multi"] = {
									nil, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
								},
							},
							["event"] = "Stance/Form/Aura",
							["unit"] = "player",
							["use_unit"] = true,
							["use_inverse"] = true,
							["subeventPrefix"] = "SPELL",
							["duration"] = "1",
							["use_form"] = false,
							["subeventSuffix"] = "_CAST_START",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "all",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["selfPoint"] = "BOTTOM",
				["desc"] = "Total Armor",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_itemequiped"] = false,
					["use_never"] = false,
					["class"] = {
						["single"] = "HUNTER",
						["multi"] = {
							["HUNTER"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
				["wordWrap"] = "WordWrap",
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "宠物状态",
				["fixedWidth"] = 200,
				["frameStrata"] = 4,
				["anchorFrameType"] = "SCREEN",
				["authorOptions"] = {
				},
				["uid"] = "VsZ9OrDHT)B",
				["color"] = {
					1, -- [1]
					0.992156862745098, -- [2]
					0.976470588235294, -- [3]
					1, -- [4]
				},
				["xOffset"] = 0,
				["config"] = {
				},
				["conditions"] = {
				},
				["justify"] = "LEFT",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
			},
		},
		["AIsE037Xq8q"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["parent"] = "角色属性",
				["displayText"] = "敏捷:%c",
				["customText"] = "function(unit, cache, textframe)\n    local agility = UnitStat(\"player\", 2)\n    \n    return (\" %.f\"):format(agility)\nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Conditions",
							["subeventPrefix"] = "SPELL",
							["use_strength"] = true,
							["names"] = {
							},
							["spellIds"] = {
							},
							["use_unit"] = true,
							["unit"] = "player",
							["ownOnly"] = true,
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Stance/Form/Aura",
							["subeventPrefix"] = "SPELL",
							["use_inverse"] = true,
							["use_unit"] = true,
							["unit"] = "player",
							["form"] = {
								["multi"] = {
									[4] = true,
								},
							},
							["use_form"] = false,
							["subeventSuffix"] = "_CAST_START",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
				["desc"] = "Current Agility",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["HUNTER"] = true,
							["WARRIOR"] = true,
							["ROGUE"] = true,
							["DRUID"] = true,
							["SHAMAN"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["selfPoint"] = "BOTTOM",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "Agility",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["color"] = {
					0.96470588235294, -- [1]
					1, -- [2]
					0.54117647058824, -- [3]
					1, -- [4]
				},
				["config"] = {
				},
				["xOffset"] = 0,
				["authorOptions"] = {
				},
				["uid"] = "AIsE037Xq8q",
				["conditions"] = {
				},
				["justify"] = "LEFT",
				["wordWrap"] = "WordWrap",
			},
		},
		["8g45pgiXFn1"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["xOffset"] = 0,
				["displayText"] = "攻击强度:%c",
				["customText"] = "function()\n    local base,posBuff,negBuff = UnitAttackPower(\"player\")\n    local effectiveAp = base + posBuff + negBuff\n    return effectiveAp\nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["actions"] = {
					["start"] = {
					},
					["init"] = {
					},
					["finish"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Conditions",
							["subeventPrefix"] = "SPELL",
							["unit"] = "player",
							["names"] = {
							},
							["spellIds"] = {
							},
							["use_unit"] = true,
							["use_strength"] = true,
							["ownOnly"] = true,
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["use_inverse"] = true,
							["event"] = "Stance/Form/Aura",
							["use_unit"] = true,
							["form"] = {
								["multi"] = {
									nil, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
								},
							},
							["unit"] = "player",
							["subeventPrefix"] = "SPELL",
							["duration"] = "1",
							["use_form"] = false,
							["subeventSuffix"] = "_CAST_START",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["selfPoint"] = "BOTTOM",
				["desc"] = "Total Armor",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["HUNTER"] = true,
							["WARRIOR"] = true,
							["PALADIN"] = true,
							["DRUID"] = true,
							["ROGUE"] = true,
							["SHAMAN"] = true,
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["wordWrap"] = "WordWrap",
				["authorOptions"] = {
				},
				["justify"] = "LEFT",
				["tocversion"] = 11302,
				["id"] = "攻强",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["uid"] = "8g45pgiXFn1",
				["config"] = {
				},
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
				["color"] = {
					1, -- [1]
					0.92549019607843, -- [2]
					0.67843137254902, -- [3]
					1, -- [4]
				},
				["parent"] = "角色属性",
				["conditions"] = {
				},
				["semver"] = "1.0.3",
				["automaticWidth"] = "Auto",
			},
		},
		["bcVFqRXLiAR"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["xOffset"] = 0,
				["displayText"] = "智力:%c",
				["customText"] = "function(unit, cache, textframe)\n    local intellect = UnitStat(\"player\", 4)\n    \n    return (\" %.f\"):format(intellect)\nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["unevent"] = "auto",
							["duration"] = "1",
							["event"] = "Conditions",
							["names"] = {
							},
							["use_strength"] = true,
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["use_unit"] = true,
							["unit"] = "player",
							["ownOnly"] = true,
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Stance/Form/Aura",
							["subeventPrefix"] = "SPELL",
							["use_inverse"] = true,
							["unit"] = "player",
							["use_unit"] = true,
							["form"] = {
								["multi"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
								},
							},
							["use_form"] = false,
							["unevent"] = "auto",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["selfPoint"] = "BOTTOM",
				["desc"] = "Current Intellect",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_never"] = false,
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["WARLOCK"] = true,
							["SHAMAN"] = true,
							["MAGE"] = true,
							["DRUID"] = true,
							["PALADIN"] = true,
							["PRIEST"] = true,
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
				["color"] = {
					0.37254901960784, -- [1]
					1, -- [2]
					0.96470588235294, -- [3]
					1, -- [4]
				},
				["justify"] = "LEFT",
				["tocversion"] = 11302,
				["id"] = "Intellect",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["config"] = {
				},
				["uid"] = "bcVFqRXLiAR",
				["wordWrap"] = "WordWrap",
				["authorOptions"] = {
				},
				["parent"] = "角色属性",
				["conditions"] = {
				},
				["semver"] = "1.0.3",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
			},
		},
		["lPpHhJru4cu"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569234595,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "THICKOUTLINE",
				["xOffset"] = 0,
				["displayText"] = "闪避:%c%",
				["customText"] = "function()\n    local dodge = GetDodgeChance()\n    return (\" %.1f\"):format(dodge)\n    \nend",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "status",
							["use_alwaystrue"] = true,
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "1",
							["event"] = "Conditions",
							["use_strength"] = true,
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["names"] = {
							},
							["unit"] = "player",
							["use_unit"] = true,
							["unevent"] = "auto",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "status",
							["unevent"] = "auto",
							["dodgepercent"] = "0",
							["duration"] = "1",
							["event"] = "Character Stats",
							["subeventPrefix"] = "SPELL",
							["use_dodgepercent"] = true,
							["subeventSuffix"] = "_CAST_START",
							["use_unit"] = true,
							["unit"] = "player",
							["dodgepercent_operator"] = ">",
						},
						["untrigger"] = {
						},
					}, -- [2]
					{
						["trigger"] = {
							["use_form"] = false,
							["unevent"] = "auto",
							["form"] = {
								["multi"] = {
								},
							},
							["event"] = "Stance/Form/Aura",
							["subeventPrefix"] = "SPELL",
							["duration"] = "1",
							["use_unit"] = true,
							["unit"] = "player",
							["use_inverse"] = false,
							["type"] = "status",
							["subeventSuffix"] = "_CAST_START",
						},
						["untrigger"] = {
						},
					}, -- [3]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
				["desc"] = "Current Dodge Chance",
				["font"] = "PT Sans Narrow",
				["version"] = 4,
				["subRegions"] = {
				},
				["load"] = {
					["use_class"] = false,
					["use_spellknown"] = false,
					["use_never"] = false,
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["single"] = "ROGUE",
						["multi"] = {
							["ROGUE"] = true,
							["WARRIOR"] = true,
							["DRUID"] = true,
							["PALADIN"] = true,
						},
					},
					["spellknown"] = 5487,
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 17,
				["regionType"] = "text",
				["wordWrap"] = "WordWrap",
				["url"] = "https://wago.io/Bu9rVLe2l/4",
				["semver"] = "1.0.3",
				["tocversion"] = 11302,
				["id"] = "Dodge Chance",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["color"] = {
					0.729411764705882, -- [1]
					0.764705882352941, -- [2]
					0.698039215686275, -- [3]
					1, -- [4]
				},
				["uid"] = "lPpHhJru4cu",
				["selfPoint"] = "BOTTOM",
				["authorOptions"] = {
				},
				["config"] = {
				},
				["conditions"] = {
				},
				["justify"] = "LEFT",
				["parent"] = "角色属性",
			},
		},
	},
	["clearOldHistory"] = 30,
	["registered"] = {
	},
	["login_squelch_time"] = 10,
	["frame"] = {
		["xOffset"] = -358.252319335938,
		["width"] = 830,
		["height"] = 665,
		["yOffset"] = -125.89306640625,
	},
	["editor_theme"] = "Monokai",
}
