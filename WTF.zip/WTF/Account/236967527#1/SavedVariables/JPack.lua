
JPackDB = {
	["version"] = "v0.7.11",
	["asc"] = true,
}
