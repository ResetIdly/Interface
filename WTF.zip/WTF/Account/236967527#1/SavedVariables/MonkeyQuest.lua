
MonkeyQuestConfig = {
	["霜语|小德阿"] = {
		["m_aQuestList"] = {
			["悬赏：黑石氏族 - false"] = {
				["m_bChecked"] = true,
			},
			["诺莫瑞根 - true"] = {
				["m_bChecked"] = false,
			},
			["群山中的嚎叫 - false"] = {
				["m_bChecked"] = true,
			},
			["黑石氏族的威胁 - false"] = {
				["m_bChecked"] = true,
			},
			["送往夜色镇的信 - false"] = {
				["m_bChecked"] = true,
			},
			["暴风城 - true"] = {
				["m_bChecked"] = true,
			},
			["收集记忆 - false"] = {
				["m_bChecked"] = true,
			},
			["通缉：范高雷中尉 - false"] = {
				["m_bChecked"] = true,
			},
			["赤脊山 - true"] = {
				["m_bChecked"] = true,
			},
			["所罗门的律法 - false"] = {
				["m_bChecked"] = true,
			},
			["暗影魔法 - false"] = {
				["m_bChecked"] = true,
			},
			["帕克斯顿修士 - false"] = {
				["m_bChecked"] = true,
			},
			["我的兄弟…… - false"] = {
				["m_bChecked"] = true,
			},
			["萨瑞尔祖恩 - false"] = {
				["m_bChecked"] = true,
			},
			["死亡矿井 - true"] = {
				["m_bChecked"] = false,
			},
			["工匠大师欧沃斯巴克 - false"] = {
				["m_bChecked"] = true,
			},
			["赤脊山炖肉 - false"] = {
				["m_bChecked"] = true,
			},
		},
	},
	["Global"] = {
		["m_bItemsEnabled"] = true,
		["m_iFont"] = 0,
		["m_strHeaderClosedColour"] = "|cFF9F9FFF",
		["m_strSpecialObjectiveColour"] = "|cFFFFFF00",
		["m_iFrameAlpha"] = 1,
		["m_bColourTitle"] = true,
		["m_strAnchor"] = "ANCHOR_TOPLEFT",
		["m_bAllowRightClick"] = true,
		["m_strZoneHighlightColour"] = "|cff494961",
		["m_strFinishObjectiveColour"] = "|cFF33DDFF",
		["m_bShowHidden"] = false,
		["m_bItemsOnLeft"] = true,
		["m_bShowNoobTips"] = true,
		["m_bHideCompletedObjectives"] = true,
		["m_bShowZoneHighlight"] = true,
		["m_strCompleteObjectiveColour"] = "|cFF00FF19",
		["m_bAlwaysHeaders"] = true,
		["m_bDisplay"] = true,
		["m_bMinimized"] = false,
		["m_strInitialObjectiveColour"] = "|cFFD82619",
		["m_iHighlightAlpha"] = 1,
		["m_bShowQuestLevel"] = true,
		["m_bShowDailyNumQuests"] = false,
		["m_iFrameBottom"] = 471.092315673828,
		["m_bHideTitleButtons"] = false,
		["m_bLocked"] = false,
		["m_bNoBorder"] = true,
		["m_bNoHeaders"] = true,
		["m_iFrameLeft"] = 1614.35461425781,
		["m_strOverviewColour"] = "|cFF7F7F7F",
		["m_iQuestPadding"] = 2,
		["m_iAlpha"] = 0,
		["m_bShowNumQuests"] = true,
		["m_iFontHeight"] = 14,
		["m_strQuestTitleColour"] = "|cFFFFFFFF",
		["m_bWorkComplete"] = true,
		["m_bHideQuestsEnabled"] = true,
		["m_strMidObjectiveColour"] = "|cFFFFFF00",
		["m_bCrashBorder"] = true,
		["m_strHeaderOpenColour"] = "|cFFBFBFFF",
		["m_iFrameTop"] = 967.476928710938,
		["m_bObjectives"] = true,
		["m_bHideHeader"] = true,
		["m_bShowTooltipObjectives"] = true,
		["m_iFrameWidth"] = 220,
		["m_bColourSubObjectivesByProgress"] = true,
		["m_bHideTitle"] = true,
		["m_bHideCompletedQuests"] = false,
		["m_bGrowUp"] = false,
	},
	["奎尔塞拉|Nue"] = {
		["m_aQuestList"] = {
			["寒脊山谷 - true"] = {
				["m_bChecked"] = true,
			},
			["矮人的交易 - false"] = {
				["m_bChecked"] = true,
			},
		},
	},
	["毁灭之刃|Aya"] = {
		["m_aQuestList"] = {
			["塞瑞娜·血羽 - false"] = {
				["m_bChecked"] = true,
			},
			["归还背包 - false"] = {
				["m_bChecked"] = true,
			},
			["狂热的维罗戈 - false"] = {
				["m_bChecked"] = true,
			},
			["雅克塞罗斯 - false"] = {
				["m_bChecked"] = true,
			},
			["茉拉·符文图腾 - false"] = {
				["m_bChecked"] = true,
			},
			["石爪之灵 - false"] = {
				["m_bChecked"] = true,
			},
			["蝎卵 - false"] = {
				["m_bChecked"] = true,
			},
			["贫瘠之地 - true"] = {
				["m_bChecked"] = true,
			},
			["石爪山脉 - true"] = {
				["m_bChecked"] = true,
			},
			["毒蛇花 - false"] = {
				["m_bChecked"] = true,
			},
			["致命的配方 - false"] = {
				["m_bChecked"] = true,
			},
			["怒焰裂谷 - true"] = {
				["m_bChecked"] = true,
			},
			["向卡德拉克报到 - false"] = {
				["m_bChecked"] = true,
			},
			["码头管理员迪兹维格 - false"] = {
				["m_bChecked"] = true,
			},
			["被偷走的银币 - false"] = {
				["m_bChecked"] = true,
			},
			["银松森林 - true"] = {
				["m_bChecked"] = true,
			},
			["哀嚎洞穴 - true"] = {
				["m_bChecked"] = true,
			},
			["杜隆塔尔 - true"] = {
				["m_bChecked"] = true,
			},
			["清除变异者 - false"] = {
				["m_bChecked"] = true,
			},
			["狂暴的镰爪龙 - false"] = {
				["m_bChecked"] = true,
			},
			["调查安伯米尔 - false"] = {
				["m_bChecked"] = true,
			},
			["阿鲁高的愚行 - false"] = {
				["m_bChecked"] = true,
			},
			["黛丽娅的戒指 - false"] = {
				["m_bChecked"] = true,
			},
			["雷霆崖 - true"] = {
				["m_bChecked"] = true,
			},
			["腐皮豺狼人的脓液 - false"] = {
				["m_bChecked"] = true,
			},
			["尖牙德鲁伊 - false"] = {
				["m_bChecked"] = true,
			},
			["至死方休 - false"] = {
				["m_bChecked"] = true,
			},
		},
	},
	["比格沃斯|Nue"] = {
		["m_aQuestList"] = {
			["提瑞斯法林地 - true"] = {
				["m_bChecked"] = false,
			},
			["遗忘之池 - false"] = {
				["m_bChecked"] = true,
			},
			["鹰身强盗 - false"] = {
				["m_bChecked"] = true,
			},
			["给银松森林送信 - false"] = {
				["m_bChecked"] = true,
			},
			["码头管理员迪兹维格 - false"] = {
				["m_bChecked"] = true,
			},
			["十字路口的补给品 - false"] = {
				["m_bChecked"] = true,
			},
			["偷钱的迅猛龙 - false"] = {
				["m_bChecked"] = true,
			},
			["贫瘠之地 - true"] = {
				["m_bChecked"] = true,
			},
			["野猪人的袭击 - false"] = {
				["m_bChecked"] = true,
			},
			["菌类孢子 - false"] = {
				["m_bChecked"] = true,
			},
			["平原陆行鸟的威胁 - false"] = {
				["m_bChecked"] = true,
			},
		},
	},
	["霜语|小雨阿"] = {
		["m_aQuestList"] = {
			["奥特兰克山脉 - true"] = {
				["m_bChecked"] = true,
			},
			["希尔斯布莱德丘陵 - true"] = {
				["m_bChecked"] = true,
			},
			["战士 - true"] = {
				["m_bChecked"] = false,
			},
			["库尔森的药物 - false"] = {
				["m_bChecked"] = true,
			},
			["吓唬病鬼 - false"] = {
				["m_bChecked"] = true,
			},
			["失踪的使节 - false"] = {
				["m_bChecked"] = true,
			},
			["巴图罗的雪人毛皮披风 - false"] = {
				["m_bChecked"] = true,
			},
			["暴风城 - true"] = {
				["m_bChecked"] = false,
			},
			["以彼之道还施彼身 - false"] = {
				["m_bChecked"] = true,
			},
			["辛迪加刺客 - false"] = {
				["m_bChecked"] = true,
			},
			["恶性竞争 - false"] = {
				["m_bChecked"] = true,
			},
			["猎虎 - false"] = {
				["m_bChecked"] = true,
			},
			["弗伦的铠甲 - false"] = {
				["m_bChecked"] = true,
			},
			["收集鳄鱼皮 - false"] = {
				["m_bChecked"] = true,
			},
			["猎豹 - false"] = {
				["m_bChecked"] = true,
			},
			["猎龙 - false"] = {
				["m_bChecked"] = true,
			},
			["荆棘谷的青山 - false"] = {
				["m_bChecked"] = true,
			},
			["荆棘谷 - true"] = {
				["m_bChecked"] = false,
			},
			["新的瘟疫？ - false"] = {
				["m_bChecked"] = true,
			},
			["荆棘谷的青山 - 第一章 - false"] = {
				["m_bChecked"] = true,
			},
			["风险投资公司 - false"] = {
				["m_bChecked"] = true,
			},
			["荆棘谷的青山 - 第三章 - false"] = {
				["m_bChecked"] = true,
			},
		},
	},
	["霜语|Aunn"] = {
		["m_aQuestList"] = {
			["镇压暴动 - false"] = {
				["m_bChecked"] = true,
			},
			["监狱 - true"] = {
				["m_bChecked"] = true,
			},
			["陀螺式挖掘机 - false"] = {
				["m_bChecked"] = true,
			},
			["诺莫瑞根 - true"] = {
				["m_bChecked"] = true,
			},
			["群山中的嚎叫 - false"] = {
				["m_bChecked"] = true,
			},
			["死亡矿井 - true"] = {
				["m_bChecked"] = true,
			},
			["所罗门的律法 - false"] = {
				["m_bChecked"] = true,
			},
			["通缉：范高雷中尉 - false"] = {
				["m_bChecked"] = true,
			},
			["西部荒野人民军 - false"] = {
				["m_bChecked"] = true,
			},
			["萨瑞尔祖恩 - false"] = {
				["m_bChecked"] = true,
			},
			["我的兄弟…… - false"] = {
				["m_bChecked"] = true,
			},
			["悬赏：黑石氏族 - false"] = {
				["m_bChecked"] = false,
			},
			["暗影魔法 - false"] = {
				["m_bChecked"] = true,
			},
			["西部荒野 - true"] = {
				["m_bChecked"] = true,
			},
			["赤脊山 - true"] = {
				["m_bChecked"] = true,
			},
		},
	},
}
