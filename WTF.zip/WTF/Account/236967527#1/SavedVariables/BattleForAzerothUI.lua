
BFAUI_SavedVars = {
	["Options"] = {
		["PixelPerfect"] = false,
		["XPBarText"] = false,
		["KeybindVisibility"] = {
			["PrimaryBar"] = true,
			["RightBar2"] = true,
			["RightBar"] = true,
			["BottomLeftBar"] = true,
			["BottomRightBar"] = true,
		},
		["HideGryphons"] = false,
	},
}
