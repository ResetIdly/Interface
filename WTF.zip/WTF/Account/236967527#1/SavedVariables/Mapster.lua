
MapsterDB = {
	["namespaces"] = {
		["FogClear"] = {
		},
		["Coords"] = {
		},
	},
	["profileKeys"] = {
		["Aya - 毁灭之刃"] = "Default",
		["Nue - 奎尔塞拉"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
