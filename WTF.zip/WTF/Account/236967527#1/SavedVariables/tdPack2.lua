
TDDB_PACK2 = {
	["profileKeys"] = {
		["Nue - 比格沃斯"] = "Default",
		["Nue - 奎尔塞拉"] = "Default",
		["Aya - 毁灭之刃"] = "Default",
		["Aunn - 霜语"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
