
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Nue - 比格沃斯"] = "Nue - 比格沃斯",
	},
	["profiles"] = {
		["Nue - 比格沃斯"] = {
		},
	},
}
