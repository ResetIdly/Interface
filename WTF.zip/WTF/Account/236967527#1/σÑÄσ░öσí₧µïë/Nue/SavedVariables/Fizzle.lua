
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Nue - 奎尔塞拉"] = "Nue - 奎尔塞拉",
	},
	["profiles"] = {
		["Nue - 奎尔塞拉"] = {
		},
	},
}
