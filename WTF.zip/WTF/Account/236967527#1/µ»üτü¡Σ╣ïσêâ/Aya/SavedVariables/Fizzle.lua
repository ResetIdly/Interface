
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Aya - 毁灭之刃"] = "Aya - 毁灭之刃",
	},
	["profiles"] = {
		["Aya - 毁灭之刃"] = {
		},
	},
}
