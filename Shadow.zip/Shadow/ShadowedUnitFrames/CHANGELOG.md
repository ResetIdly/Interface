# Shadowed Unit Frames

## [v4.2-Classic-Beta6](https://github.com/Nevcairiel/ShadowedUnitFrames/tree/v4.2-Classic-Beta6) (2019-08-31)
[Full Changelog](https://github.com/Nevcairiel/ShadowedUnitFrames/compare/v4.2-Classic-Beta5...v4.2-Classic-Beta6)

- Fix druid mana bar visibility  
- Fix visibility of party pet frames  
- Use follow range instead of inspect range, since inspect range is significantly reduced on Classic  
