﻿--[[--
	alex@0
--]]--
----------------------------------------------------------------------------------------------------
local ADDON, NS = ...;
----------------------------------------------------------------------------------------------------
NS.PATH = "Interface\\AddOns\\alaChat\\";
NS.ICON_PATH = "Interface\\AddOns\\alaChat\\icon\\";
NS.EMOTE_PATH = "Interface\\AddOns\\alaChat\\emote\\";
