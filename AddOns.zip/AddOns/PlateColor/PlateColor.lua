-- credits to:
-- HopeASD (NGA qfeizaijun)/ 简繁(NGA zhangzhanxian3)
local addonName, addon = ...

addon[1] = {} -- Gloable
addon[2] = {} -- Function
addon[3] = {} -- Config
addon[4] = {} -- Locale

local G, F, C, L = unpack(addon)

local events = {}

local host = CreateFrame("Frame")
host:SetScript("OnEvent", function(_, event, ...)
	for func in pairs(events[event]) do
		if event == "COMBAT_LOG_EVENT_UNFILTERED" then
			func(event, CombatLogGetCurrentEventInfo())
		else
			func(event, ...)
		end
	end
end)

function G:RegisterEvent(event, func, unit1, unit2)
	if not events[event] then
		events[event] = {}
		if unit1 then
			host:RegisterUnitEvent(event, unit1, unit2)
		else
			host:RegisterEvent(event)
		end
	end

	events[event][func] = true
end

function G:UnregisterEvent(event, func)
	local funcs = events[event]
	if funcs and funcs[func] then
		funcs[func] = nil

		if not next(funcs) then
			events[event] = nil
			host:UnregisterEvent(event)
		end
	end
end

local DefaultDB = {
name = true,
arrow = true,
scale =true,
texture = true,
jian = true,
ch = true,
mb = true,
sf = true,
pvp = true,
hp = false,
hps = 1,
iKillper = 0,
nScale = 0.7,
dq = 1,
qt = 1,
zt = 1,
oh = 0.6,
ov = 0.8,
color = {
    ["rgb1"] = {r=1, g=0, b=0}, 
    ["rgb2"] = {r=0.3, g=0, b=0.6},
	["rgb3"] = {r=0.2, g=0.3, b=0.6},
	["rgb4"] = {r=1, g=0.5, b=0},
	["rgb5"] = {r=0, g=1, b=1},
	["rgb6"] = {r=0, g=1, b=0},
	["rgb7"] = {r=1, g=0, b=1},
}

}

local eventframe = CreateFrame("Frame")
eventframe:RegisterEvent("ADDON_LOADED")
eventframe:SetScript("OnEvent",function(self,_,addon)
	if addon ~= "PlateColor" then return end
	if not PlateColorDB then PlateColorDB = {} end
	
		for i, j in pairs(DefaultDB) do
		if type(j) == "table" then
			if PlateColorDB[i] == nil then PlateColorDB[i] = {} end
			for k, v in pairs(j) do
				if PlateColorDB[i][k] == nil then
					PlateColorDB[i][k] = v
				end
			end
		else
			if PlateColorDB[i] == nil then PlateColorDB[i] = j end
		end
	end
	self:UnregisterAllEvents()

end)
local function TestFunc()


if PlateColorDB.name ==  true  then 
--名字放大並描邊 NGA@EKE:https://bbs.nga.cn/read.php?tid=11956803
local function SetFont(obj, optSize) 
local fontName, _,fontFlags  = obj:GetFont() 
obj:SetFont(fontName,optSize,"OUTLINE") 
obj:SetShadowOffset(0, 0) 
end 
local ds
if GetCVar("gxFullscreenResolution") == "1920x1080"
then ds = 17
else
ds = 12
end

SetFont(SystemFont_LargeNamePlate,ds) 
SetFont(SystemFont_NamePlate,10) 
SetFont(SystemFont_LargeNamePlateFixed,ds) 
SetFont(SystemFont_NamePlateFixed,10) 
SetFont(SystemFont_NamePlateCastBar,ds)
SetCVar("namePlateMinScale", 1)  --default is 0.8 
SetCVar("namePlateMaxScale", 1)
end
--加载一次滑动条的cvar
SetCVar("nameplateGlobalScale", PlateColorDB.nScale)	--全局缩放
SetCVar("nameplateSelectedScale", PlateColorDB.dq)	--当前缩放
SetCVar("nameplateLargerScale", PlateColorDB.dq)	--首领缩放
SetCVar("nameplateMaxAlpha", PlateColorDB.qt)	--10码外
SetCVar("nameplateMinAlpha", PlateColorDB.qt)	--10码内
SetCVar("nameplateOccludedAlphaMult", PlateColorDB.zt)	--障碍物后透明度

--堆叠间距
if PlateColorDB.jian == true then
--SetCVar("nameplateMotion", 1) --姓名版堆叠
SetCVar("nameplateOverlapH",  0.6)
SetCVar("nameplateOverlapV",  0.8)

SetCVar("UnitNameEnemyPlayerName",1) --敌对玩家
SetCVar("UnitNameEnemyMinionName",1) --敌对玩家仆从
SetCVar("nameplateShowEnemies",1) --敌对玩家血条
SetCVar("nameplateShowEnemyMinions",1) --敌对玩家仆从血条
SetCVar("nameplateShowEnemyMinus",1) --敌对玩家杂兵血条
SetCVar("nameplateShowAll",1) --显示所有姓名版
--姓名版帖边
SetCVar("nameplateOtherTopInset", 0.08) 
SetCVar("nameplateOtherBottomInset", 0.1) 
SetCVar("nameplateLargeTopInset", 0.08) 
SetCVar("nameplateLargeBottomInset", 0.1)

else
SetCVar("nameplateOverlapH",  0.8)
SetCVar("nameplateOverlapV",  1.1)
end

if GetCVar("nameplateShowOnlyNames") ~= 0 then
SetCVar("nameplateShowOnlyNames", 0)	--关闭仅显示名字模式
end

--https://bbs.nga.cn/read.php?&tid=17230932&pid=338690228&to=1
local frame = CreateFrame('Frame') 
frame:RegisterEvent('NAME_PLATE_UNIT_ADDED') 
frame:SetScript('OnEvent', function(self, event, namePlateUnitToken) 
    local plate = C_NamePlate.GetNamePlateForUnit(namePlateUnitToken) 

    -- play with plate here 
    plate.UnitFrame.BuffFrame:SetBaseYOffset(0)
	--plate.UnitFrame.BuffFrame:SetScale(2)
end)


if PlateColorDB.texture == true then
local ThinCastBar = function(frame)
if frame:IsForbidden() then return end
if not frame:GetName():find("NamePlate%d") then return end
	frame.healthBar:SetStatusBarTexture(.75,.75,.75)
	--frame.castBar:SetStatusBarTexture(.75,.75,.75)
	--frame.healthBar.border:Hide()	--隐藏黑边框
	--frame.healthBar.border:SetAlpha(.4)
end
hooksecurefunc("CompactUnitFrame_UpdateName", ThinCastBar)
end

--血条右侧显示箭头
hooksecurefunc("CompactUnitFrame_UpdateSelectionHighlight", function(frame)
	if not frame.optionTable.displaySelectionHighlight then return end
	if frame:IsForbidden() then return end
	if frame and frame:GetName():find("NamePlate%d") then
		if not frame.arrow then
			frame.arrow = frame:CreateTexture(nil, "PARENT")
			frame.arrow:SetTexture("Interface\\Addons\\PlateColor\\blue.tga")		-- 图标路径
			frame.arrow:SetPoint("right", frame.healthBar, "right", 55, 0)				-- 右方箭头位置
			frame.arrow:SetSize(60, 60)										-- 箭头大小
			frame.arrow:SetAlpha(0)
		end
		if UnitIsUnit(frame.displayedUnit, "target") and PlateColorDB.arrow ==  true then
			frame.arrow:SetAlpha(1)
		else
			frame.arrow:SetAlpha(0)
		end
	end
end)

--血条变色
hooksecurefunc("CompactUnitFrame_OnUpdate", function(frame)
   if C_NamePlate.GetNamePlateForUnit(frame.unit) ~= C_NamePlate.GetNamePlateForUnit("player") and not UnitIsPlayer(frame.unit) and not CompactUnitFrame_IsTapDenied(frame) then
	  local threat = UnitThreatSituation("player", frame.unit) or 0
	  local reaction = UnitReaction(frame.unit, "player")
	  local name = UnitName(frame.unit)
	  local me = UnitName("player")
	  local pt = UnitIsUnit(frame.unit.."target", me)
	  --local buff1 = UnitBuff(frame.unit,1)
	  local Cur = UnitHealth(frame.unit)
	  local Max = UnitHealthMax(frame.unit)
	  local Per = Cur/Max*100
	  local guid = UnitGUID(frame.unit)
	  local _, _, _, _, _, id = strsplit("-", guid or "") 
	  local combat = UnitAffectingCombat(frame.unit)
	  
	    if id == "120651" then --邪能炸药
			r, g, b = PlateColorDB.color.rgb6.r,PlateColorDB.color.rgb6.g,PlateColorDB.color.rgb6.b
		elseif Per <=  PlateColorDB.iKillper then	--斩杀
			r, g, b = PlateColorDB.color.rgb7.r,PlateColorDB.color.rgb7.g,PlateColorDB.color.rgb7.b
		elseif (id == "134389") and pt == true and PlateColorDB.ch == true then
			r, g, b = PlateColorDB.color.rgb2.r,PlateColorDB.color.rgb2.g,PlateColorDB.color.rgb2.b
		elseif threat == 3  and PlateColorDB.ch == true then
            r, g, b = PlateColorDB.color.rgb2.r,PlateColorDB.color.rgb2.g,PlateColorDB.color.rgb2.b   -- 仇恨是你 颜色
		elseif threat == 2 and PlateColorDB.ch == true then      
            r, g, b = PlateColorDB.color.rgb3.r,PlateColorDB.color.rgb3.g,PlateColorDB.color.rgb3.b	--仇恨降低  颜色
        elseif threat == 1 and PlateColorDB.ch == true then      
            r, g, b = PlateColorDB.color.rgb4.r,PlateColorDB.color.rgb4.g,PlateColorDB.color.rgb4.b		-- 高仇恨  颜色
		elseif UnitIsUnit(frame.displayedUnit, "target") and PlateColorDB.mb == true then
			r, g, b = PlateColorDB.color.rgb5.r,PlateColorDB.color.rgb5.g,PlateColorDB.color.rgb5.b	-- 你的目标 颜色	
		elseif combat == true then
			r, g, b = PlateColorDB.color.rgb1.r,PlateColorDB.color.rgb1.g,PlateColorDB.color.rgb1.b	--战斗状态
		elseif reaction == 4 then
			r, g, b = 1, 1, 0		-- 中立怪 黄色
		elseif reaction >= 5 then
			r, g, b = 0, 1, 0		-- 友方npc 绿色
        else
			r, g, b = 1, 0, 0
        end
      frame.healthBar:SetStatusBarColor(r, g, b, 1)
   end
end) 

local ta = function(frame)
if frame:IsForbidden() then return end
if not frame:GetName():find("NamePlate%d") then return end
if frame then
local namea = UnitName(frame.unit.."target")
local myname = UnitName("Player")
local players = UnitIsPlayer(frame.unit)
local _, class = UnitClass(frame.unit.."target")
color = CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[class] or RAID_CLASS_COLORS[class]
if not frame.ta then
frame.ta = frame.healthBar:CreateFontString(nil, "ARTWORK")
frame.ta:SetFont(STANDARD_TEXT_FONT, 20, 'OUTLINE')
frame.ta:SetPoint("LEFT",frame,"RIGHT",-60,15)
frame.ta:Hide()
elseif PlateColorDB.sf == true and players == false then
if UnitChannelInfo(frame.unit) == nil then
frame.ta:SetText(namea) 
if UnitCastingInfo(frame.unit) ~= nil then	--and frame.ta:GetText() == myname then
if color then frame.ta:SetTextColor(color.r, color.g, color.b) end
frame.ta:Show()
else
frame.ta:Hide()
end
end
elseif PlateColorDB.pvp == true and players == true then
if color then frame.ta:SetTextColor(color.r, color.g, color.b) end
frame.ta:SetText(namea)
if frame.ta:GetText() == myname then
frame.ta:Show()
else
frame.ta:Hide()
end
else frame.ta:Hide()
end
end
end
hooksecurefunc("CompactUnitFrame_OnUpdate", ta)

local hp = function(frame)
local iType = 3
if frame:IsForbidden() then return end
if not frame:GetName():find("NamePlate%d") then return end
if frame then
if not frame.hp then
frame.hp = frame.healthBar:CreateFontString(nil, "ARTWORK")
frame.hp:SetFont(STANDARD_TEXT_FONT, GetCVar("NamePlateHorizontalScale")*15-6, 'OUTLINE')
else
local CurHealth = UnitHealth(frame.unit)
local MaxHealth = UnitHealthMax(frame.unit)
local fPer = string.format("%.0f",(CurHealth/MaxHealth*100)).."%"
local fCur = nil
if CurHealth > 10000 then
		fCur = string.format("%.1f",CurHealth/10000).."w"
	else
		fCur = tostring(CurHealth)
end
if PlateColorDB.hps == 1 then
frame.hp:SetPoint("RIGHT",0,0)
frame.hp:SetText(fCur)
elseif PlateColorDB.hps == 2 then
frame.hp:SetPoint("RIGHT",0,0)
frame.hp:SetText(fPer)
elseif PlateColorDB.hps == 3 then
frame.hp:SetPoint("CENTER",5,0)
frame.hp:SetText(fCur.." - "..fPer)
end

if PlateColorDB.hp == true then
frame.hp:Show()
else
frame.hp:Hide()
end
end
end
end
hooksecurefunc("CompactUnitFrame_OnUpdate", hp)

--[[
local function BoomBall()
	local haskey = false

	for i, namePlate in ipairs(C_NamePlate.GetNamePlates()) do
		local unitFrame = namePlate.UnitFrame
		local guid = UnitGUID(unitFrame.unit)
		local _, _, _, _, _, id = strsplit("-", guid or "") 
		if id == "120651" then
			haskey = true
		end
	end	

	-- 场上存在易爆球
	if haskey then 
			for i, namePlate in ipairs(C_NamePlate.GetNamePlates()) do
				local unitFrame = namePlate.UnitFrame
				local guid = UnitGUID(unitFrame.unit)
				local _, _, _, _, _, id = strsplit("-", guid or "") 
				if id ~= "120651" then
					unitFrame:Hide()
				end
			end
	else
			for i, namePlate in ipairs(C_NamePlate.GetNamePlates()) do
				local unitFrame = namePlate.UnitFrame
				unitFrame:Show()
			end		

	end
end

local boomFrame = CreateFrame("Frame")
local timei = 0 
boomFrame:SetScript("OnUpdate", function (self, elasped)
	--if not SavedData["Expball"] then return end
	timei = timei + elasped
	if timei > 0.2 then
		BoomBall()
		timei = 0
	end
end)--]]

end

G:RegisterEvent("PLAYER_LOGIN",TestFunc)

local function defa()
PlateColorDB = {
	["dq"] = 1,
	["color"] = {
		["rgb6"] = {
			["b"] = 0,
			["g"] = 1,
			["r"] = 0,
		},
		["rgb5"] = {
			["b"] = 1,
			["g"] = 1,
			["r"] = 0,
		},
		["rgb2"] = {
			["b"] = 0.6,
			["g"] = 0,
			["r"] = 0.3,
		},
		["rgb3"] = {
			["b"] = 0.6,
			["g"] = 0.3,
			["r"] = 0.2,
		},
		["rgb1"] = {
			["b"] = 0,
			["g"] = 0,
			["r"] = 1,
		},
		["rgb7"] = {
			["b"] = 1,
			["g"] = 0,
			["r"] = 1,
		},
		["rgb4"] = {
			["b"] = 0,
			["g"] = 0.5,
			["r"] = 1,
		},
	},
	["hp"] = false,
	["nScale"] = 0.7,
	["ov"] = 0.8,
	["texture"] = true,
	["hps"] = 1,
	["oh"] = 0.6,
	["mb"] = true,
	["sf"] = true,
	["ch"] = true,
	["name"] = true,
	["jian"] = true,
	["iKillper"] = 0,
	["arrow"] = true,
	["scale"] = true,
	["pvp"] = true,
}
end

local function CreateColorBlock(parent, anchorframe, x, y)
    parent.color = parent:CreateTexture(nil, "BACKGROUND")
    parent.color:SetPoint("TOPLEFT", anchorframe, "TOPLEFT", x, y)
    parent.color:SetSize(70, 15)
    parent.color:SetColorTexture(PlateColorDB.color[parent.name].r,PlateColorDB.color[parent.name].g,PlateColorDB.color[parent.name].b)
    
    parent.btn = CreateFrame("Button", nil, parent, "GameMenuButtonTemplate");
    parent.btn:SetPoint("TOPLEFT", anchorframe, "TOPLEFT", x, y);
    parent.btn:SetSize(70, 15);
    parent.btn:SetAlpha(0)
    parent.btn:SetNormalFontObject("GameFontNormalLarge");
    parent.btn:SetHighlightFontObject("GameFontHighlightLarge");

    local onUpdate = function(restore)
        local r, g, b = ColorPickerFrame:GetColorRGB()
        parent.color:SetColorTexture(r, g, b)
        PlateColorDB.color[parent.name].r,PlateColorDB.color[parent.name].g,PlateColorDB.color[parent.name].b = r,g,b
    end

    local onCancel = function()
        local r, g, b = ColorPicker_GetPreviousValues()
        parent.color:SetColorTexture(r, g, b)
        PlateColorDB.color[parent.name].r,PlateColorDB.color[parent.name].g,PlateColorDB.color[parent.name].b = r,g,b
    end

    parent.btn:SetScript("OnClick", function(self, button, down)
       local r,g,b = PlateColorDB.color[parent.name].r,PlateColorDB.color[parent.name].g,PlateColorDB.color[parent.name].b
       ColorPickerFrame.func = onUpdate
       ColorPickerFrame.previousValues = {r = r, g = g, b = b}
       ColorPickerFrame.cancelFunc = onCancel
       ColorPickerFrame:SetColorRGB(r, g, b)
       ColorPickerFrame:Show() 
    end)
--[[
    parent.btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_CURSOR ", 20, -20)
        GameTooltip:SetText(parent.name)
        GameTooltip:Show()
    end)
    parent.btn:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)]]
end
local function CreateColorFrame(name, parent)
    local f = CreateFrame("Frame", nil, parent)
    f.name = name
    f.r, f.g, f.b, f.a = unpack(PlateColorDB.color[name])
    f.Create = CreateColorBlock
    return f
end

local function CreateColorBlocks(parent, anchorFrame, x, y)
    local rgb1 = CreateColorFrame("rgb1", parent)
    rgb1:SetPoint("TOPLEFT", anchorFrame, "TOPLEFT", x, y)
    rgb1:Create(anchorFrame, x, y)
    
    local rgb2 = CreateColorFrame("rgb2", parent)
    rgb2:SetPoint("TOPLEFT", rgb1, "TOPLEFT", x, y)
    rgb2:Create(anchorFrame, x, y - 34)
	
	local rgb3 = CreateColorFrame("rgb3", parent)
    rgb3:SetPoint("TOPLEFT", rgb1, "TOPLEFT", x, y)
    rgb3:Create(anchorFrame, x, y - 68)
	
	local rgb4 = CreateColorFrame("rgb4", parent)
    rgb4:SetPoint("TOPLEFT", rgb1, "TOPLEFT", x, y)
    rgb4:Create(anchorFrame, x, y - 102)
	
	local rgb5 = CreateColorFrame("rgb5", parent)
    rgb5:SetPoint("TOPLEFT", rgb1, "TOPLEFT", x, y)
    rgb5:Create(anchorFrame, x, y - 136)
	
	local rgb6 = CreateColorFrame("rgb6", parent)
    rgb6:SetPoint("TOPLEFT", rgb1, "TOPLEFT", x, y)
    rgb6:Create(anchorFrame, x, y - 170)
	
	local rgb7 = CreateColorFrame("rgb7", parent)
    rgb7:SetPoint("TOPLEFT", rgb1, "TOPLEFT", x, y)
    rgb7:Create(anchorFrame, x, y - 204)

end

local frame = CreateFrame("Frame", nil, InterfaceOptionsFrame)
frame.name = addonName
frame:SetScript("OnShow", function(frame)
	
	local PlateColor = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	PlateColor:SetPoint("TOPLEFT", 16, -15)
	PlateColor:SetText("PlateColor")
	PlateColor:SetFont("fonts\\ARHei.ttf", 30, "OUTLINE")
	
	local Color = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	Color:SetPoint("TOPLEFT", 160, -30)
	Color:SetText("一个基于原始姓名版的插件")
	Color:SetFont("fonts\\ARHei.ttf", 15, nil)
	
	local clear = CreateFrame("Button", "AddUISaveButton", frame, "UIPanelButtonTemplate")
	clear:SetText("恢复默认")
	clear:SetWidth(177)
	clear:SetHeight(24)
	clear:SetPoint("TOPLEFT", 380, -30)
	clear:SetScript("OnClick", function()
		defa()
	end)
	
	local s1 = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	s1:SetPoint("TOPLEFT", 460, -60)
	s1:SetText("正常")
	local s2 = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	s2:SetPoint("TOPLEFT", 460, -94)
	s2:SetText("仇恨是你")
	local s3 = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	s3:SetPoint("TOPLEFT", 460, -128)
	s3:SetText("仇恨不稳")
	local s4 = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	s4:SetPoint("TOPLEFT", 460, -162)
	s4:SetText("仇恨高")
	local s5 = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	s5:SetPoint("TOPLEFT", 460, -196)
	s5:SetText("你的目标")
	local s6 = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	s6:SetPoint("TOPLEFT", 460, -230)
	s6:SetText("易爆球")
	local s7 = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	s7:SetPoint("TOPLEFT", 460, -264)
	s7:SetText("斩杀")
	CreateColorBlocks(frame, frame, 380, -61)
	
	local qqun = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	qqun:SetPoint("BOTTOMRIGHT", -10, 10)
	qqun:SetText("斗鱼:323075\n\nQQ群:718148969")
	qqun:SetJustifyH("RIGHT")

	local function newCheckbox(label, description, onClick)
		local check = CreateFrame("CheckButton", "PlateColorCheck" .. label, frame, "InterfaceOptionsCheckButtonTemplate")
		check:SetScript("OnClick", function(self)
			local tick = self:GetChecked()
			onClick(self, tick and true or false)
		end)
		check.label = _G[check:GetName() .. "Text"]
		check.label:SetText(label)
		check.tooltipText = description
		--check.tooltipRequirement = description
		return check
	end
	
	local namec = newCheckbox("血条名字美化|cffFFC0CB(重载生效)|r","ekk的血条名字美化",function(self, value) PlateColorDB.name = value end)
	namec:SetChecked(PlateColorDB.name)
	namec:SetPoint("TOPLEFT", 16, -60)
	
	local jianc = newCheckbox("血条相关CVar|cffFFC0CB(重载生效)|r","ESC-界面-名字,自动勾选相关设置",function(self, value) PlateColorDB.jian = value end)
	jianc:SetChecked(PlateColorDB.jian)
	jianc:SetPoint("TOPLEFT", 16, -90)
	
	local texturec = newCheckbox("血条扁平材质|cffFFC0CB(重载生效)|r","扁平材质血条",function(self, value) PlateColorDB.texture = value end)
	texturec:SetChecked(PlateColorDB.texture)
	texturec:SetPoint("TOPLEFT", 16, -120)
	
	local arrowc = newCheckbox("血条右侧箭头|cffFFC0CB|r","当前目标右侧蓝色箭头",function(self, value) PlateColorDB.arrow = value end)
	arrowc:SetChecked(PlateColorDB.arrow)
	arrowc:SetPoint("TOPLEFT", 16, -150)
	
	local chc = newCheckbox("仇恨变色","根据仇恨不同显示不同颜色",function(self, value) PlateColorDB.ch = value end)
	chc:SetChecked(PlateColorDB.ch)
	chc:SetPoint("TOPLEFT", 16, -180)
	
	local mbc = newCheckbox("当前目标变色","更容易区分当前目标和非当前目标",function(self, value) PlateColorDB.mb = value end)
	mbc:SetChecked(PlateColorDB.mb)
	mbc:SetPoint("TOPLEFT", 16, -210)
	
	local sfc = newCheckbox("施法预警","对你读条血条上会显示你的名字",function(self, value) PlateColorDB.sf = value end)
	sfc:SetChecked(PlateColorDB.sf)
	sfc:SetPoint("TOPLEFT", 16, -240)
	
	local pvpc = newCheckbox("被集火预警(PvP)","敌对玩家目标是你血条上会显示你的名字",function(self, value) PlateColorDB.pvp = value end)
	pvpc:SetChecked(PlateColorDB.pvp)
	pvpc:SetPoint("TOPLEFT", 16, -270)
	
	local mbc = newCheckbox("显示生命值","在血条上显示当前生命值文本",function(self, value) PlateColorDB.hp = value end)
	mbc:SetChecked(PlateColorDB.hp)
	mbc:SetPoint("TOPLEFT", 16, -300)
	
	local info = {}
	local hpDropdown = CreateFrame("Frame", "hpcursor", frame, "UIDropDownMenuTemplate")
	hpDropdown:SetPoint("TOPLEFT", 0, -330)
	hpDropdown.initialize = function()
		wipe(info)
		local fonts = {1, 2, 3}
		local names = {"数值", "百分比", "同时显示"}
		for i, font in next, fonts do
			info.text = names[i]
			info.value = font
			info.func = function(self)
				PlateColorDB.hps = self.value
				hpcursorText:SetText(self:GetText())
			end
			info.checked = font == PlateColorDB.hps
			UIDropDownMenu_AddButton(info)
		end
	end
	local xsfs
	if PlateColorDB.hps == 1 then xsfs = "数值" elseif PlateColorDB.hps == 2 then xsfs = "百分比" elseif PlateColorDB.hps == 1 then xsfs = "同时显示" end
	hpcursorText:SetText(xsfs)
	
	local function newSlider(SliderName, x, y, minValue, maxValue, curValue, valueStep, lowText, highText, upText, tipText, varformat)
		local pSlider = CreateFrame("Slider", "Slider"..SliderName , frame, "OptionsSliderTemplate" );
		pSlider:SetPoint("TOPLEFT", frame, "TOPLEFT", x, y);
		pSlider:SetMinMaxValues(minValue, maxValue);
		pSlider:SetValue(curValue);
		pSlider:SetValueStep(valueStep);
		pSlider:SetObeyStepOnDrag(true);
		pSlider.textLow = _G["Slider"..SliderName.."Low"]
		pSlider.textHigh = _G["Slider"..SliderName.."High"]
		pSlider.text = _G["Slider"..SliderName.."Text"]
		pSlider.textLow:SetText(lowText)
		pSlider.textHigh:SetText(highText)
		pSlider.text:SetText("|cffFFD700"..upText.." :  "..string.format(varformat,pSlider:GetValue()).."|r")

		pSlider:SetScript("OnValueChanged", 
		function(pSlider,event,arg1) 
			pSlider.text:SetText("|cffFFD700"..upText.." :  "..string.format(varformat,pSlider:GetValue()).."|r")
		end)
		pSlider.tooltipText = tipText
		-- body
		return pSlider
	end
	
	frame.pKillper = newSlider("iKillper", 380, -320, 0, 100, 0, 1, "关", "高血线", "斩杀线", "设置斩杀线,0关闭染色","%d%%")
	frame.pKillper:SetValue(PlateColorDB.iKillper)
	frame.pKillper:HookScript("OnValueChanged", function(self, value)
		PlateColorDB.iKillper = tonumber(string.format("%d",self:GetValue()))
	end)

	frame.nScale = newSlider("nScale", 25, -470, 0.5, 2, 0.7, 0.1, "小", "大", "姓名版缩放", "设置姓名版大小","%.1f")
	frame.nScale:SetValue(PlateColorDB.nScale)
	frame.nScale:HookScript("OnValueChanged", function(self, value)
		PlateColorDB.nScale = tonumber(string.format(self:GetValue()))
		SetCVar("nameplateGlobalScale", PlateColorDB.nScale)
	end)
	
	frame.dq = newSlider("dq", 25, -520, 1, 1.5, 1, 0.1, "小", "大", "当前目标缩放", "当前目标大小","%.1f")
	frame.dq:SetValue(PlateColorDB.dq)
	frame.dq:HookScript("OnValueChanged", function(self, value)
		PlateColorDB.dq = tonumber(string.format(self:GetValue()))
		SetCVar("nameplateSelectedScale", PlateColorDB.dq)
		SetCVar("nameplateLargerScale", PlateColorDB.dq)
	end)
	
	frame.qt = newSlider("qt", 225, -470, 0.1, 1, 1, 0.1, "低", "高", "血条透明度", "全局透明度","%.1f")
	frame.qt:SetValue(PlateColorDB.qt)
	frame.qt:HookScript("OnValueChanged", function(self, value)
		PlateColorDB.qt = tonumber(string.format(self:GetValue()))
		SetCVar("nameplateMaxAlpha", PlateColorDB.qt)	--10码外
		SetCVar("nameplateMinAlpha", PlateColorDB.qt)	--10码内
	end)
	
	frame.zt = newSlider("zt", 225, -520, 0.1, 1, 1, 0.1, "低", "高", "障碍物透明度", "障碍物后的血条透明度","%.1f")
	frame.zt:SetValue(PlateColorDB.zt)
	frame.zt:HookScript("OnValueChanged", function(self, value)
		PlateColorDB.zt = tonumber(string.format(self:GetValue()))
		SetCVar("nameplateOccludedAlphaMult", PlateColorDB.zt)	--障碍物后透明度
	end)

	
	frame:SetScript("OnShow", nil)
end)

InterfaceOptions_AddCategory(frame)
SLASH_PlateColor1 = "/pc"
SlashCmdList["PlateColor"] = function() 
    InterfaceOptionsFrame_OpenToCategory(frame)
	InterfaceOptionsFrame_OpenToCategory(frame)
end