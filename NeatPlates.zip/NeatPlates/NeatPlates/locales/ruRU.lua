local L = LibStub("AceLocale-3.0"):NewLocale("NeatPlates", "ruRU")
if not L then return end


L = L or {}
L["CLASSIC_DURATION_SEC_PATTERN"] = "([0-9]+%.?[0-9]?)%sсек"
