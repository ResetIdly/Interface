﻿--[[--
	alex@0
--]]--
----------------------------------------------------------------------------------------------------
local ADDON, NS = ...;
----------------------------------------------------------------------------------------------------
NS.PATH = "Interface\\AddOns\\alaChat_Classic\\";
NS.ICON_PATH = "Interface\\AddOns\\alaChat_Classic\\icon\\";
NS.EMOTE_PATH = "Interface\\AddOns\\alaChat_Classic\\emote\\";
