﻿U1RegisterAddon("alaChat_Classic", {
    title = "ala聊天增强",
    tags = { TAG_CHAT },
    desc = "ala聊天增强",
    load = "NORMAL",
    defaultEnable = 1,
    nopic = 1,

    {
        text = "配置选项",
        callback = function(cfg, v, loading)
                InterfaceOptionsFrame_Show();
                InterfaceOptionsFrame_OpenToCategory("alaChat_Classic");
        end
    }
});
