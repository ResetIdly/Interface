# Modern QuestWatch

## [1.0.8](https://github.com/ketho-wow/ModernQuestWatch/tree/1.0.8) (2019-08-12)
[Full Changelog](https://github.com/ketho-wow/ModernQuestWatch/compare/1.0.7...1.0.8)

- Fixed quest tracker to only expand downwards.  
    This will reset the config  
