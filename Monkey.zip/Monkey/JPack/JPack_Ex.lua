﻿--[[
	JPack_Ex: A button on you bag frame!
	orig: zyleon@sohu.com
	maintenance: yaroot@gmail.com
]]

local L = _G.JPackLocale

local addon = CreateFrame("frame")
addon:SetScript("OnEvent", function(self, event, ...) self[event](self, event, ...) end)

local function OnClick(self, button)
	local access, order
	if ( button == "LeftButton" ) then
	    PlaySound(SOUNDKIT.IG_CHAT_EMOTE_BUTTON)
		if IsShiftKeyDown() then
			access = 1
		elseif IsControlKeyDown() then
			access = 2
		elseif IsAltKeyDown() then
			access = 3
		end
	elseif ( button == "RightButton" ) then
	    PlaySound(SOUNDKIT.IG_CHAT_EMOTE_BUTTON)
		if IsShiftKeyDown() then
			order = 1
		elseif IsControlKeyDown() then
			order = 2
		end
	end
	JPack:Pack(access, order)
end


local function OnEnter(self)
	GameTooltip:SetOwner(self, "ANCHOR_LEFT")
	GameTooltip:AddLine(L["Pack"])
	GameTooltip:Show()
end

local function OnLeave()
	GameTooltip:Hide()
end

function BuildButton(parent, width, height, point1, point2, point3)
	local f = CreateFrame("Button", nil, parent)
	f:SetNormalTexture("Interface\\AddOns\\JPack\\Media\\INV_Pet_Broom.blp");
	f:SetPushedTexture("Interface\\AddOns\\JPack\\Media\\INV_Pet_BroomDown.blp");
    f:SetHighlightTexture("Interface\\AddOns\\JPack\\Media\\ButtonHilight-Square.blp");
	f:SetWidth(width)
	f:SetHeight(height)
	f:SetPoint(point1, point2, point3)
	--f:SetText(L["Pack"])
	f:SetScript("OnMouseDown", OnClick)
	f:SetScript("OnEnter", OnEnter)
	f:SetScript("OnLeave", OnLeave)
	return f
end

function addon:ADDON_LOADED(event,addon)
	if addon ~= "Blizzard_GuildBankUI" then return end
	BuildButton(GuildBankFrame, 25, 25, "TOPRIGHT", -25, -15)
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil
end

function addon:PLAYER_LOGIN()
	addon:UnregisterEvent("PLAYER_LOGIN")
	if IsAddOnLoaded("ArkInventory") then
		local i = 1
		while i do
			local arkframe = _G["ARKINV_Frame"..i]
			if not arkframe then break end
			BuildButton(arkframe, 25, 25, "TOPRIGHT", -135, -15)
			i = i + 1
		end
		return
	elseif IsAddOnLoaded("Baggins") then
		BuildButton(BagginsBag1, 25, 25, "TOPRIGHT", -30, -6)
		BuildButton(BagginsBag12, 25, 25, "TOPRIGHT", -30, -6)	
	elseif IsAddOnLoaded("BaudBag") then
		BuildButton(BaudBagContainer1_1, 25, 25, "TOPRIGHT", -54, 40)
		BuildButton(BaudBagContainer2_1, 25, 25, "TOPRIGHT", -54, 40)	
	elseif IsAddOnLoaded("Inventorian") then
		BuildButton(InventorianBagFrame, 25, 25, "TOPRIGHT", -48, -30)
		BuildButton(InventorianBankFrame, 25, 25, "TOPRIGHT", -48, -30)		
	elseif IsAddOnLoaded("Combuctor") then
		CombuctorFrame1Search:SetPoint("TOPRIGHT",-166,-44)
		CombuctorFrame2Search:SetPoint("TOPRIGHT",-166,-44)
		BuildButton(CombuctorFrame1, 25, 25, "TOPRIGHT", -50, -40)
		BuildButton(CombuctorFrame2, 25, 25, "TOPRIGHT", -50, -40)
	elseif IsAddOnLoaded("MyInventory") then
		BuildButton(MyInventoryFrame, 25, 25, "TOPRIGHT", -15, -35)
		BuildButton(MyBankFrame, 25, 25, "TOPRIGHT", -15, -35)
	elseif IsAddOnLoaded("OneBag3") or IsAddOnLoaded("OneBank3") then
		if IsAddOnLoaded("OneBag3") then
			BuildButton(OneBagFrame, 25, 25, "TOPRIGHT", -105, -10)
		end
		if IsAddOnLoaded("OneBank3") then
			BuildButton(OneBankFrame, 25, 25, "TOPRIGHT", -105, -10)
		end
	else
		BuildButton(ContainerFrame1, 25, 25, "TOPRIGHT", -10, -28)
		BuildButton(BankFrame, 25, 25, "TOPRIGHT", -50, -15)
	end
	
	if JPack.DEV_MOD then addon:RegisterEvent("ADDON_LOADED") end
end

addon:RegisterEvent("PLAYER_LOGIN")
