﻿local function OnTooltipSetItem(frame, ...)
	local name, link = frame:GetItem()
	if not link then return end
	local _,_,_,_,_,_,_,stackCount = GetItemInfo(link)
		if (stackCount and stackCount ~= 1) then
		frame:AddDoubleLine( "最大堆叠:  "..stackCount)
	end
end
for _,frame in pairs{ItemRefTooltip} do
	GameTooltip:HookScript("OnTooltipSetItem", OnTooltipSetItem)
	frame:SetScript("OnTooltipSetItem", OnTooltipSetItem)
end